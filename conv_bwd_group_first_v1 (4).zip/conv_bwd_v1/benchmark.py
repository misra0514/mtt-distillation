"""Paired native-layout benchmark for first-order convolution backward."""
import argparse
import contextlib
import hashlib
import json
import sys
import traceback
from datetime import datetime
import itertools
import math
import random
import statistics as stats
import time
from collections import defaultdict
from pathlib import Path

import torch
import triton
from conv_bwd import conv_bwd, _backward, winograd_fits


def cases(models, datasets, stem):
    for model,dataset in itertools.product(models,datasets):
        size = 32 if dataset == "cifar10" else 64
        layers = defaultdict(list)
        def add(name,c,o,h,k=3,s=1,p=1):
            layers[c,o,h,k,s,p].append(name)
            return (h+2*p-k)//s+1
        h = size
        if model == "conv3":
            for layer in range(3):
                add(f"conv{layer+1}",3 if layer == 0 else 128,128,h)
                h //= 2
        else:
            standard = stem == "standard" or (stem == "auto" and size == 64)
            h = add("stem",3,64,h,7,2,3) if standard else add("stem",3,64,h)
            if standard:
                h = (h+1)//2
            c = 64
            for stage,o in enumerate((64,128,256,512)):
                for block in range(2):
                    s = 2 if stage and block == 0 else 1
                    name = f"s{stage+1}b{block+1}"
                    old = h
                    h = add(name+".conv1",c,o,h,s=s)
                    add(name+".conv2",o,o,h)
                    if s != 1:
                        add(name+".shortcut",c,o,old,1,s,0)
                    c = o
        for shape,names in layers.items():
            yield model,dataset,shape,names


def original(x,w,d,st,pad,dil,groups):
    args = (st,pad,dil,groups)
    return (torch.nn.grad.conv2d_input(x.shape,w,d,*args),
            torch.nn.grad.conv2d_weight(x,w.shape,d,*args),d.sum((0,2,3)))


def aten(x,w,d,st,pad,dil,groups):
    return torch.ops.aten.convolution_backward.default(
        d,x,w,[w.size(0)],st,pad,dil,False,[0,0],groups,[True,True,True])


def pack(t):
    g,b,c,h,w = t.shape
    return t.transpose(0,1).reshape(b,g*c,h,w).contiguous()


def unpack(t,g):
    b,gc,h,w = t.shape
    return t.reshape(b,g,gc//g,h,w).transpose(0,1).contiguous()


def tensors(shape,st,pad,dil,inner=1,noncontig=False):
    g,b,c,h,w,o,r,s = shape
    p = (h+2*pad[0]-dil[0]*(r-1)-1)//st[0]+1
    q = (w+2*pad[1]-dil[1]*(s-1)-1)//st[1]+1
    def rand(*dims):
        if noncontig:
            return torch.randn(*dims[:-2],dims[-1],dims[-2],device="cuda").transpose(-1,-2)
        return torch.randn(*dims,device="cuda")
    return rand(g,b,c,h,w),rand(g,o,c//inner,r,s),rand(g,b,o,p,q)


def compare(a,b,relative=4e-4):
    # Bound transient memory even for B=1000. Accumulate error norms in FP64.
    if a.shape != b.shape:
        raise AssertionError(f"shape mismatch {a.shape} / {b.shape}")
    # Only flatten a contiguous slice, important for native grouped references.
    limit = 1 << 20
    metrics = torch.zeros(4,dtype=torch.float64,device=a.device)
    def visit(aa,bb):
        if aa.numel() > limit:
            axis = max(range(aa.ndim),key=lambda k: aa.shape[k])
            step = max(1,aa.shape[axis]*limit//aa.numel())
            for start in range(0,aa.shape[axis],step):
                n = min(step,aa.shape[axis]-start)
                visit(aa.narrow(axis,start,n),bb.narrow(axis,start,n))
            return
        u = aa.double()
        v = bb.double()
        delta = (u-v).abs()
        metrics[0].add_(delta.square().sum())
        metrics[1].add_(v.square().sum())
        metrics[2].copy_(torch.maximum(metrics[2],delta.max()))
        metrics[3].copy_(torch.maximum(metrics[3],v.abs().max()))
    visit(a,b)
    e,n,m,peak = metrics.tolist()
    rel_l2 = math.sqrt(e)/max(math.sqrt(n),1e-12)
    if not (rel_l2 <= relative and m <= 2e-4+2e-3*peak):
        raise AssertionError(f"rel_l2={rel_l2:g}, max_abs={m:g}, ref_peak={peak:g}")
    return rel_l2


def check_cases():
    # Include odd tails, non-square stride/dilation, independence between outer
    # groups, inner channel grouping, 4D and both ends of the batch range.
    specs = [
        ((3,2,5,9,7,7,3,3),(1,1),(1,1),(1,1),1),
        ((2,3,33,9,7,17,3,3),(2,2),(1,0),(1,1),1),
        ((2,2,12,11,8,18,2,3),(2,1),(0,2),(2,2),3),
        ((8,1,3,15,17,17,7,7),(2,2),(3,3),(1,1),1),
        ((1,1000,4,5,4,5,1,1),(1,1),(0,0),(1,1),1),
        ((4,3,32,9,7,35,3,3),(1,1),(1,1),(1,1),1),
        ((1,1,3,1,2,4,3,3),(2,2),(1,1),(1,1),1),
    ]
    for j,(shape,st,pad,dil,i) in enumerate(specs):
        x,w,d = tensors(shape,st,pad,dil,i,noncontig=(j==2))
        if shape[0] > 1:
            d[-1].zero_()
        algorithms = ["auto","direct"]
        if (shape[-2:],st,pad,dil,i)==((3,3),(1,1),(1,1),(1,1),1):
            algorithms.append("winograd")
        for alg in algorithms:
            # Compare every group and output to the given reference in FP64.
            y = _backward(x,w,d,st,pad,dil,i,alg)
            for g in range(shape[0]):
                ref = original(x[g].double(),w[g].double(),d[g].double(),st,pad,dil,i)
                for actual,target in zip(y,ref):
                    compare(actual[g],target)
            if i==1 and alg=="auto":
                alias = conv_bwd(x,w,d,st,pad,dil,x.size(0))
                for aa,bb in zip(alias,y):
                    compare(aa,bb)
        flat = conv_bwd(x[0],w[0],d[0],st,pad,dil,i)
        ref = original(x[0].double(),w[0].double(),d[0].double(),st,pad,dil,i)
        for aa,bb in zip(flat,ref):
            compare(aa,bb)
        print("correctness PASS",shape,algorithms,flush=True)


def once(fn,n):
    torch.cuda.synchronize()
    a,b = (torch.cuda.Event(enable_timing=True) for _ in range(2))
    start = time.perf_counter()
    a.record()
    for _ in range(n):
        fn()
    b.record()
    b.synchronize()
    return a.elapsed_time(b)/n,1000*(time.perf_counter()-start)/n


def paired(funcs,a):
    counts = {}
    samples = {k:[] for k in funcs}
    peak = {}
    for k,fn in funcs.items():
        for _ in range(a.warmup):
            fn()
        torch.cuda.synchronize()
        duration = once(fn,2)[0]
        counts[k] = min(a.iters,max(2,math.ceil(a.target_ms/max(duration,0.001))))
        torch.cuda.reset_peak_memory_stats()
        base = torch.cuda.memory_allocated()
        fn()
        torch.cuda.synchronize()
        peak[k] = (torch.cuda.max_memory_allocated()-base)/2**20
    rng = random.Random(131)
    for _ in range(a.rounds):
        names = list(funcs)
        rng.shuffle(names)
        for k in names:
            samples[k].append(once(funcs[k],counts[k]))
    times = {}
    for k,pairs in samples.items():
        ev,wall = zip(*pairs)
        cv = lambda v: 100*stats.stdev(v)/max(stats.mean(v),1e-9)
        times[k]=(stats.median(ev),stats.median(wall),cv(ev),cv(wall),peak[k])
    return times


def profile(fn):
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                           torch.profiler.ProfilerActivity.CUDA]) as prof:
        fn()
        torch.cuda.synchronize()
    totals = defaultdict(float)
    for e in prof.events():
        if e.device_type == torch.autograd.DeviceType.CUDA:
            totals[e.name] += e.time_range.elapsed_us()
    return "; ".join(f"{k}={v:.1f}us" for k,v in sorted(totals.items(),key=lambda p:-p[1])[:6])


def run_case(shape,g,b,a):
    c,o,h,k,s,pad = shape
    st,pads,dil = (s,s),(pad,pad),(1,1)
    x,w,d = tensors((g,b,c,h,h,o,k,k),st,pads,dil)
    xp,dp,wp = pack(x),pack(d),w.flatten(0,1)
    def from_native(y):
        return (unpack(y[0],g),y[1].view_as(w),y[2].view(g,o))
    funcs = {
        "torch_given": lambda: original(xp,wp,dp,st,pads,dil,g),
        "aten": lambda: aten(xp,wp,dp,st,pads,dil,g),
        "aten_serial": lambda: [aten(x[j],w[j],d[j],st,pads,dil,1) for j in range(g)],
        "auto": lambda: conv_bwd(x,w,d,st,pads,dil),
    }
    if a.e2e:
        funcs["aten_e2e"] = lambda: from_native(aten(pack(x),wp,pack(d),st,pads,dil,g))
    if a.candidates:
        funcs["direct"] = lambda: _backward(x,w,d,st,pads,dil,1,"direct")
        if (k,s,pad)==(3,1,1) and winograd_fits(g,b,c,o,h,h):
            funcs["winograd"] = lambda: _backward(x,w,d,st,pads,dil,1,"winograd")
    # Per-shape correctness vs the supplied Torch code on original data.
    ref = funcs["torch_given"]()
    targets = (ref[0].unflatten(1,(g,c)).transpose(0,1),ref[1].view_as(w),ref[2].view(g,o))
    rel = {}
    for key in ("auto","direct","winograd"):
        if key in funcs:
            out = funcs[key]()
            rel[key] = max(compare(aa,bb) for aa,bb in zip(out,targets))
            del out
    del ref,targets
    measured = paired(funcs,a)
    if a.profile:
        for name in ("auto","aten","torch_given"):
            print(f"  profile {name}",profile(funcs[name]),flush=True)
    return measured,rel


def points(a):
    if a.groups or a.batch:
        return list(itertools.product(a.groups or [1,2,4],a.batch or [1,10,100,1000]))
    small = itertools.product((1,2,4,8,16,32),(1,4))
    large = itertools.product((1,2,4),(1,10,32,100,256,512,1000))
    seq = small if a.sweep=="small" else large if a.sweep=="large" else itertools.chain(small,large)
    return list(dict.fromkeys(seq))


def verdict(ms,ref,cv):
    if cv > 5:
        return "unstable"
    ratio = ref/ms
    if ref < .05:
        return "small_ok" if ms <= max(ref*1.2,ref+.010) else "small_regression"
    if ratio > 1.03:
        return "hot_win"
    return "near_tie" if ratio >= .97 else "hot_regression"


def print_case_shapes(a):
    print("SHAPE_SUITE G=outer independent group, B=batch per group",flush=True)
    print("Conv3 configuration: channel=3 width=128 depth=3 kernel=3 stride=1 padding=1 "
          "pooling=2x2 stride2 after EVERY block",flush=True)
    print("SHAPE rows describe convolution tensors before each block's pooling.",flush=True)
    for model,dataset,shape,names in cases(a.models,a.datasets,a.stem):
        c,o,h,k,st,pad=shape
        q=(h+2*pad-k)//st+1
        print("SHAPE",json.dumps(dict(
            model=model,dataset=dataset,layers=names,multiplicity=len(names),
            x=f"[G,B,{c},{h},{h}]",weight=f"[G,{o},{c},{k},{k}]",
            grad_output=f"[G,B,{o},{q},{q}]",grad_x=f"[G,B,{c},{h},{h}]",
            grad_weight=f"[G,{o},{c},{k},{k}]",grad_bias=f"[G,{o}]",
            stride=st,padding=pad,dilation=1)),flush=True)
    if "conv3" in a.models:
        for dataset in a.datasets:
            size=32 if dataset=="cifar10" else 64
            print("CONV3_FEATURE_OUTPUT",dataset,f"[G,B,128,{size//8},{size//8}]",
                  "after third pooling",flush=True)


def print_summary(records):
    totals = defaultdict(list)
    for row in records:
        if row["status"] != "ok" or row["provider"] == "auto":
            totals[row["model"],row["dataset"],row["G"],row["B"]].append(row)
    print("Isolated layer medians weighted by multiplicity; fastest native Torch per shape.")
    for (model,dataset,g,b),rows in totals.items():
        ok = [r for r in rows if r["status"]=="ok"]
        n = sum(int(r["multiplicity"]) for r in rows)
        done = sum(int(r["multiplicity"]) for r in ok)
        if done != n:
            print(f"  {model}/{dataset} G={g} B={b}: partial coverage {done}/{n}; see log")
            continue
        top = sorted(ok,key=lambda r:float(r["torch_layer_ms"]),reverse=True)[:3]
        native = sum(float(r["torch_layer_ms"]) for r in ok)
        custom = sum(float(r["event_ms"])*int(r["multiplicity"]) for r in ok)
        print(f"  {model}/{dataset} G={g} B={b}: {native/custom:.3f}x, "
              f"auto={custom:.3f}ms torch={native:.3f}ms ({done} layer calls)")
        for r in top:
            print("    ",r["layers"],f'{100*float(r["torch_layer_ms"])/native:.1f}% Torch time',
                  f'{float(r["vs_best_torch"]):.3f}x',r["verdict"])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check",action="store_true",help="FP64 reference suite, then exit")
    parser.add_argument("--models",nargs="+",choices=["conv3","resnet18"],default=["conv3","resnet18"])
    parser.add_argument("--datasets",nargs="+",choices=["cifar10","tinyimagenet"],default=["cifar10","tinyimagenet"])
    parser.add_argument("--stem",choices=["auto","small","standard"],default="auto")
    parser.add_argument("--sweep",choices=["small","large","both"],default="both")
    parser.add_argument("--groups",type=int,nargs="+")
    parser.add_argument("--batch",type=int,nargs="+")
    parser.add_argument("--eff-floor",type=float,default=.8,help="efficiency cutoff for near-linear flag")
    parser.add_argument("--rounds",type=int,default=5)
    parser.add_argument("--warmup",type=int,default=5)
    parser.add_argument("--target-ms",type=float,default=50.)
    parser.add_argument("--iters",type=int,default=100)
    parser.add_argument("--candidates",action="store_true")
    parser.add_argument("--e2e",action="store_true",help="also measure ATen from/to contiguous group-first")
    parser.add_argument("--profile",action="store_true",help="CUPTI timings per kernel, outside timed rounds")
    parser.add_argument("--output",type=Path,default=Path("conv_bwd.txt"),help="tee stdout and stderr into this TXT file")
    a=parser.parse_args()
    if not 0 < a.eff_floor <= 1 or a.rounds<2 or a.iters<2 or a.warmup<1 or a.target_ms<=0 or any(v<1 for v in (a.groups or [])+(a.batch or [])):
        parser.error("expected positive values, with --rounds and --iters >=2")
    a.output.parent.mkdir(parents=True,exist_ok=True)
    with a.output.open("w",encoding="utf-8",buffering=1) as log:
        out,err = Tee(sys.stdout,log),Tee(sys.stderr,log)
        with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
            try:
                with torch.no_grad():
                    run(a)
            except Exception:
                traceback.print_exc()
                raise SystemExit(1)


class Tee:
    def __init__(self,console,log):
        self.console,self.log=console,log

    def write(self,text):
        self.console.write(text)
        self.log.write(text)
        self.flush()
        return len(text)

    def flush(self):
        self.console.flush()
        self.log.flush()


def run(a):
    print("START",datetime.now().astimezone().isoformat(),flush=True)
    print("ARGS",json.dumps(vars(a),default=str,sort_keys=True),flush=True)
    print("SOURCE_SHA256",json.dumps({
        name:hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
        for name in ("benchmark.py","conv_bwd.py")}),flush=True)
    torch.manual_seed(17)
    torch.backends.cudnn.allow_tf32=False
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.benchmark=True
    print("Torch",torch.__version__,"Triton",triton.__version__,"CUDA",torch.version.cuda,
          "cuDNN",torch.backends.cudnn.version(),"GPU",torch.cuda.get_device_name(),"FP32 IEEE",flush=True)
    print_case_shapes(a)
    if a.check:
        check_cases()
        return
    matrix=points(a)
    records=[]
    for model,dataset,shape,names in cases(a.models,a.datasets,a.stem):
        c,o,h,k,s,p=shape
        data={}
        for g,b in sorted(matrix):
            base=dict(model=model,dataset=dataset,C=c,O=o,H=h,K=k,stride=s,padding=p,
                      layers="|".join(names),multiplicity=len(names),G=g,B=b)
            try:
                times,errs=run_case(shape,g,b,a)
            except torch.cuda.OutOfMemoryError:
                row=dict(base,status="OOM")
                records.append(row)
                print("RESULT",json.dumps(row,sort_keys=True),flush=True)
                print(model,dataset,names[0],g,b,"OOM",flush=True)
                continue
            best=min(("aten","torch_given","aten_serial"),key=lambda key:times[key][0])
            ref=times[best][0]
            print(model,dataset,names[0],"G",g,"B",b,f"auto {times['auto'][0]:.4f} ms",
                  f"{best} {ref:.4f} ms",f"{ref/times['auto'][0]:.2f}x",flush=True)
            data[g,b]=times
            for key,(ms,wall,cv,wcv,peak) in times.items():
                row=dict(base,status="ok",provider=key,event_ms=ms,wall_ms=wall,event_cv_pct=cv,
                         wall_cv_pct=wcv,peak_extra_MiB=peak,images_s=1000*g*b/ms,
                         reference=best,vs_best_torch=ref/ms,rel_l2=errs.get(key,""),
                         torch_layer_ms=len(names)*ref)
                if key in errs:
                    row["verdict"]=verdict(ms,ref,max(cv,wcv,*times[best][2:4]))
                for axis,origin,n in [("G",(1,b),g),("B",(g,1),b)]:
                    if origin in data:
                        t0=data[origin][key] if key in data[origin] else None
                        if t0 is not None:
                            eff=t0[0]/ms
                            row["S_"+axis]=n*eff
                            row["E_"+axis]=eff
                            stable=max(cv,t0[2])<=5
                            row["scaling_"+axis+"_stable"]=stable
                            if n > 1 and stable:
                                row["near_linear_"+axis]=eff >= a.eff_floor
                records.append(row)
                print("RESULT",json.dumps(row,sort_keys=True),flush=True)
    print_summary(records)
    print("FINISHED",datetime.now().astimezone().isoformat(),flush=True)


if __name__=="__main__":
    main()
