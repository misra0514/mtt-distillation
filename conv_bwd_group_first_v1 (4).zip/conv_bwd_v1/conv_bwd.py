"""Group-first convolution backward. Stateless FP32 kernels for NVIDIA GPUs."""
import operator

import torch
import triton
import triton.language as tl

# F(2x2,3x3) transforms adapted from the project convolution kernels.

@triton.jit
def _win_input(X,g,ci,t,tr,tc,F:tl.constexpr,C:tl.constexpr,H:tl.constexpr,W:tl.constexpr,
               TH:tl.constexpr,TW:tl.constexpr,PH:tl.constexpr,PW:tl.constexpr):
    f=t//(TH*TW); y=t//TW%TH*2-PH; x=t%TW*2-PW
    r0=tl.where(tr==0,0,1);r1=tl.where(tr==3,3,2)
    c0=tl.where(tc==0,0,1);c1=tl.where(tc==3,3,2)
    sr0=tl.where(tr>=2,-1.,1.);sr1=tl.where(tr==0,-1.,1.)
    sc0=tl.where(tc>=2,-1.,1.);sc1=tl.where(tc==0,-1.,1.)
    base=((g*F+f)*C+ci)*H*W
    valid=(f<F)&(ci<C)
    a=tl.load(X+base+(y+r0)*W+x+c0,valid&(y+r0>=0)&(y+r0<H)&(x+c0>=0)&(x+c0<W),0)
    b=tl.load(X+base+(y+r0)*W+x+c1,valid&(y+r0>=0)&(y+r0<H)&(x+c1>=0)&(x+c1<W),0)
    c=tl.load(X+base+(y+r1)*W+x+c0,valid&(y+r1>=0)&(y+r1<H)&(x+c0>=0)&(x+c0<W),0)
    d=tl.load(X+base+(y+r1)*W+x+c1,valid&(y+r1>=0)&(y+r1<H)&(x+c1>=0)&(x+c1<W),0)
    return sr0*(sc0*a+sc1*b)+sr1*(sc0*c+sc1*d)

@triton.jit
def _win_g(tr,k:tl.constexpr):
    return tl.where(tr==0,1. if k==0 else 0.,tl.where(tr==3,1. if k==2 else 0.,tl.where((tr==2)&(k==1),-.5,.5)))

@triton.jit
def _win_weight(Wt,g,oc,ci,tr,tc,C:tl.constexpr,O:tl.constexpr,FLIP:tl.constexpr):
    v=tl.full((oc.shape[0],ci.shape[1]),0,tl.float32)
    for r in tl.static_range(3):
        for s in tl.static_range(3):
            coef=_win_g(tr,r)*_win_g(tc,s)
            if FLIP:off=g*O*C*9+ci*O*9+oc*9+(2-r)*3+2-s
            else:off=g*O*C*9+oc*C*9+ci*9+r*3+s
            w=tl.load(Wt+off,(oc<O)&(ci<C),0)
            v+=coef*w
    return v

@triton.jit
def _win_weight_pack(Wt,U,G:tl.constexpr,C:tl.constexpr,O:tl.constexpr,FLIP:tl.constexpr):
    pid=tl.program_id(0);g=tl.program_id(1);z=tl.program_id(2)
    oc=pid//tl.cdiv(C,32)*16+tl.arange(0,16)
    ci=pid%tl.cdiv(C,32)*32+tl.arange(0,32)
    v=_win_weight(Wt,g,oc[:,None],ci[None,:],z//4,z%4,C,O,FLIP)
    tl.store(U+((z*G+g)*O+oc[:,None])*C+ci[None,:],v,(oc[:,None]<O)&(ci[None,:]<C))

@triton.jit
def _win_out(M,Bias,Y,start,G:tl.constexpr,F:tl.constexpr,O:tl.constexpr,P:tl.constexpr,Q:tl.constexpr,
             NT:tl.constexpr,HB:tl.constexpr,BLOCK:tl.constexpr):
    i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK)
    n=i%NT;oc=i//NT%O;g=i//(NT*O);t=start+n
    f=t//(((P+1)//2)*((Q+1)//2));y=t//((Q+1)//2)%((P+1)//2)*2;x=t%((Q+1)//2)*2
    valid=(i<G*O*NT)&(f<F)
    base=(g*O+oc)*NT+n;step=G*O*NT
    m00=tl.load(M+0*step+base,valid,0)
    m01=tl.load(M+1*step+base,valid,0)
    m02=tl.load(M+2*step+base,valid,0)
    m03=tl.load(M+3*step+base,valid,0)
    m10=tl.load(M+4*step+base,valid,0)
    m11=tl.load(M+5*step+base,valid,0)
    m12=tl.load(M+6*step+base,valid,0)
    m13=tl.load(M+7*step+base,valid,0)
    m20=tl.load(M+8*step+base,valid,0)
    m21=tl.load(M+9*step+base,valid,0)
    m22=tl.load(M+10*step+base,valid,0)
    m23=tl.load(M+11*step+base,valid,0)
    m30=tl.load(M+12*step+base,valid,0)
    m31=tl.load(M+13*step+base,valid,0)
    m32=tl.load(M+14*step+base,valid,0)
    m33=tl.load(M+15*step+base,valid,0)
    v00=m00+m10+m20
    v10=m10-m20+m30
    v01=m01+m11+m21
    v11=m11-m21+m31
    v02=m02+m12+m22
    v12=m12-m22+m32
    v03=m03+m13+m23
    v13=m13-m23+m33
    bias=tl.load(Bias+g*O+oc,valid,0) if HB else tl.full((BLOCK,),0,tl.float32)
    tl.store(Y+((g*F+f)*O+oc)*P*Q+(y+0)*Q+x+0,v00+v01+v02+bias,valid&(y+0<P)&(x+0<Q))
    tl.store(Y+((g*F+f)*O+oc)*P*Q+(y+0)*Q+x+1,v01-v02+v03+bias,valid&(y+0<P)&(x+1<Q))
    tl.store(Y+((g*F+f)*O+oc)*P*Q+(y+1)*Q+x+0,v10+v11+v12+bias,valid&(y+1<P)&(x+0<Q))
    tl.store(Y+((g*F+f)*O+oc)*P*Q+(y+1)*Q+x+1,v11-v12+v13+bias,valid&(y+1<P)&(x+1<Q))

@triton.jit
def _win_dout(D,g,oc,t,tr,tc,F:tl.constexpr,O:tl.constexpr,P:tl.constexpr,Q:tl.constexpr):
    TH:tl.constexpr=((P+1)//2);TW:tl.constexpr=((Q+1)//2)
    f=t//(TH*TW);y=t//TW%TH*2;x=t%TW*2
    base=((g*F+f)*O+oc)*P*Q+y*Q+x
    valid=(f<F)&(oc<O)
    a=tl.load(D+base,valid&(y<P)&(x<Q)&(tr!=3)&(tc!=3),0)
    b=tl.load(D+base+1,valid&(y<P)&(x+1<Q)&(tr!=3)&(tc!=0),0)
    c=tl.load(D+base+Q,valid&(y+1<P)&(x<Q)&(tr!=0)&(tc!=3),0)
    d=tl.load(D+base+Q+1,valid&(y+1<P)&(x+1<Q)&(tr!=0)&(tc!=0),0)
    sr=tl.where(tr==2,-1.,1.);sc=tl.where(tc==2,-1.,1.)
    return a+sc*b+sr*c+sr*sc*d

@triton.jit
def _win_gw_out(U,Y,G:tl.constexpr,O:tl.constexpr,C:tl.constexpr,SK:tl.constexpr,BLOCK:tl.constexpr):
    i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK);g=i//(O*C);j=i%(O*C)
    valid=i<G*O*C
    u0=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u0+=tl.load(U+((g*SK+part)*16+0)*O*C+j,valid,0)
    u1=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u1+=tl.load(U+((g*SK+part)*16+1)*O*C+j,valid,0)
    u2=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u2+=tl.load(U+((g*SK+part)*16+2)*O*C+j,valid,0)
    u3=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u3+=tl.load(U+((g*SK+part)*16+3)*O*C+j,valid,0)
    u4=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u4+=tl.load(U+((g*SK+part)*16+4)*O*C+j,valid,0)
    u5=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u5+=tl.load(U+((g*SK+part)*16+5)*O*C+j,valid,0)
    u6=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u6+=tl.load(U+((g*SK+part)*16+6)*O*C+j,valid,0)
    u7=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u7+=tl.load(U+((g*SK+part)*16+7)*O*C+j,valid,0)
    u8=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u8+=tl.load(U+((g*SK+part)*16+8)*O*C+j,valid,0)
    u9=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u9+=tl.load(U+((g*SK+part)*16+9)*O*C+j,valid,0)
    u10=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u10+=tl.load(U+((g*SK+part)*16+10)*O*C+j,valid,0)
    u11=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u11+=tl.load(U+((g*SK+part)*16+11)*O*C+j,valid,0)
    u12=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u12+=tl.load(U+((g*SK+part)*16+12)*O*C+j,valid,0)
    u13=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u13+=tl.load(U+((g*SK+part)*16+13)*O*C+j,valid,0)
    u14=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u14+=tl.load(U+((g*SK+part)*16+14)*O*C+j,valid,0)
    u15=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u15+=tl.load(U+((g*SK+part)*16+15)*O*C+j,valid,0)
    v0=u0+0.5*(u4+u8)
    v4=0.5*(u4-u8)
    v8=0.5*(u4+u8)+u12
    v1=u1+0.5*(u5+u9)
    v5=0.5*(u5-u9)
    v9=0.5*(u5+u9)+u13
    v2=u2+0.5*(u6+u10)
    v6=0.5*(u6-u10)
    v10=0.5*(u6+u10)+u14
    v3=u3+0.5*(u7+u11)
    v7=0.5*(u7-u11)
    v11=0.5*(u7+u11)+u15
    tl.store(Y+i*9+0,v0+0.5*(v1+v2),valid)
    tl.store(Y+i*9+1,0.5*(v1-v2),valid)
    tl.store(Y+i*9+2,0.5*(v1+v2)+v3,valid)
    tl.store(Y+i*9+3,v4+0.5*(v5+v6),valid)
    tl.store(Y+i*9+4,0.5*(v5-v6),valid)
    tl.store(Y+i*9+5,0.5*(v5+v6)+v7,valid)
    tl.store(Y+i*9+6,v8+0.5*(v9+v10),valid)
    tl.store(Y+i*9+7,0.5*(v9-v10),valid)
    tl.store(Y+i*9+8,0.5*(v9+v10)+v11,valid)

@triton.jit
def _pack_tiles(X,V,start,G:tl.constexpr,F:tl.constexpr,C:tl.constexpr,H:tl.constexpr,W:tl.constexpr,
                P:tl.constexpr,Q:tl.constexpr,PH:tl.constexpr,PW:tl.constexpr,NT:tl.constexpr,
                DOUT:tl.constexpr,BLOCK:tl.constexpr):
    i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK)
    g=tl.program_id(1);z=tl.program_id(2);ci=i//NT;n=i%NT;t=start+n
    if DOUT:
        v=_win_dout(X,g,ci,t,z//4,z%4,F,C,H,W)
    else:
        v=_win_input(X,g,ci,t,z//4,z%4,F,C,H,W,(P+1)//2,(Q+1)//2,PH,PW)
    tl.store(V+((z*G+g)*C+ci)*NT+n,v,ci<C)

@triton.jit
def _packed_conv(U,V,M,G:tl.constexpr,C:tl.constexpr,O:tl.constexpr,NT:tl.constexpr,
                 ADD:tl.constexpr,PREC:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    pid=tl.program_id(0);g=tl.program_id(1);z=tl.program_id(2)
    nn=tl.cdiv(NT,BN);nm=tl.cdiv(O,BM)
    first=pid//(4*nn)*4;count=tl.minimum(nm-first,4)
    oc=(first+pid%(4*nn)%count)*BM+tl.arange(0,BM)
    n=(pid%(4*nn)//count)*BN+tl.arange(0,BN);kk=tl.arange(0,BK)
    acc=tl.zeros((BM,BN),tl.float32)
    for cb in range(tl.cdiv(C,BK)):
        ci=cb*BK+kk
        a=tl.load(U+((z*G+g)*O+oc[:,None])*C+ci[None,:],(oc[:,None]<O)&(ci[None,:]<C),0)
        b=tl.load(V+((z*G+g)*C+ci[:,None])*NT+n[None,:],(ci[:,None]<C)&(n[None,:]<NT),0)
        acc=tl.dot(a,b,acc,input_precision=PREC)
    off=((z*G+g)*O+oc[:,None])*NT+n[None,:];mask=(oc[:,None]<O)&(n[None,:]<NT)
    if ADD:acc+=tl.load(M+off,mask,0)
    tl.store(M+off,acc,mask)

@triton.jit
def _packed_gw(V,D,U,DB,G:tl.constexpr,C:tl.constexpr,O:tl.constexpr,NT:tl.constexpr,
               PREC:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    pid=tl.program_id(0);g=tl.program_id(1);z=tl.program_id(2)
    oc=pid//tl.cdiv(C,BN)*BM+tl.arange(0,BM);ci=pid%tl.cdiv(C,BN)*BN+tl.arange(0,BN)
    kk=tl.arange(0,BK);acc=tl.zeros((BM,BN),tl.float32)
    bias=tl.full((BM,),0,tl.float32)
    owner=(z==5)&(pid%tl.cdiv(C,BN)==0)
    for kb in range(tl.cdiv(NT,BK)):
        k=kb*BK+kk
        a=tl.load(D+((z*G+g)*O+oc[:,None])*NT+k[None,:],(oc[:,None]<O)&(k[None,:]<NT),0)
        b=tl.load(V+((z*G+g)*C+ci[None,:])*NT+k[:,None],(ci[None,:]<C)&(k[:,None]<NT),0)
        if owner:
            bias+=tl.sum(a,1)
        acc=tl.dot(a,b,acc,input_precision=PREC)
    tl.store(U+((g*16+z)*O+oc[:,None])*C+ci[None,:],acc,(oc[:,None]<O)&(ci[None,:]<C))
    if owner:
        tl.store(DB+g*O+oc,bias,oc<O)


def winograd_fits(g,b,c,o,h,w):
    nt = b * triton.cdiv(h,2) * triton.cdiv(w,2)
    return nt <= 2048 and 4 * 16 * g * (o*c + (o+c)*nt) <= (128 << 20)


def winograd_backward(x, weight, dy, dx, dw, db):
    g,b,c,h,w = x.shape
    o = weight.shape[1]
    nt = b * triton.cdiv(h,2) * triton.cdiv(w,2)
    # dx = correlation(dy, rotated/transposed weight). Reuse all three
    # transformed buffers for dw once the dx write has been enqueued.
    u = x.new_empty((16,g,c,o))
    d = x.new_empty((16,g,o,nt))
    v = x.new_empty((16,g,c,nt))
    _win_weight_pack[(triton.cdiv(c,16)*triton.cdiv(o,32),g,16)](weight,u,g,o,c,True)
    _pack_tiles[(triton.cdiv(o*nt,256),g,16)](dy,d,0,g,b,o,h,w,h,w,1,1,nt,False,256)
    _packed_conv[(triton.cdiv(c,32)*triton.cdiv(nt,32),g,16)](u,d,v,g,o,c,nt,False,"ieee",32,32,16)
    _win_out[(triton.cdiv(g*c*nt,128),)](v,dy,dx,0,g,b,c,h,w,nt,False,128)
    _pack_tiles[(triton.cdiv(c*nt,256),g,16)](x,v,0,g,b,c,h,w,h,w,1,1,nt,False,256)
    _pack_tiles[(triton.cdiv(o*nt,256),g,16)](dy,d,0,g,b,o,h,w,h,w,0,0,nt,True,256)
    # Transform component (1,1) contains the sum of each 2x2 dy tile.
    _packed_gw[(triton.cdiv(o,32)*triton.cdiv(c,32),g,16)](v,d,u,db,g,c,o,nt,"ieee",32,32,16)
    _win_gw_out[(triton.cdiv(g*o*c,64),)](u,dw,g,o,c,1,64)



@triton.jit
def _dx_tile(D, WT, DX, B: tl.constexpr, C: tl.constexpr, O: tl.constexpr,
             H: tl.constexpr, W: tl.constexpr, P: tl.constexpr, Q: tl.constexpr,
             R: tl.constexpr, S: tl.constexpr, SH: tl.constexpr, SW: tl.constexpr,
             PH: tl.constexpr, PW: tl.constexpr, DH: tl.constexpr, DW: tl.constexpr,
             I: tl.constexpr, PARITY: tl.constexpr, RH: tl.constexpr, RW: tl.constexpr,
             BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    # Each program owns a (channel, batch/spatial) tile of dx.
    task = tl.program_id(1).to(tl.int64)
    outer = task // I
    inner = task % I
    u = tl.program_id(0)
    scale: tl.constexpr = 2 if PARITY else 1
    rows: tl.constexpr = (H + scale - 1 - RH) // scale
    cols: tl.constexpr = (W + scale - 1 - RW) // scale
    ntiles: tl.constexpr = tl.cdiv(B * tl.cdiv(H, scale) * tl.cdiv(W, scale), BN)
    ci = (u // ntiles) * BM + tl.arange(0, BM)
    n = (u % ntiles) * BN + tl.arange(0, BN)
    batch = (n // (rows * cols)).to(tl.int64)
    iy = n // cols % rows * scale + RH
    ix = n % cols * scale + RW
    kk = tl.arange(0, BK)
    dy_sample = ((outer * B + batch) * I + inner) * O * P * Q
    w_group = WT + task * O * C * R * S
    acc = tl.zeros((BM, BN), tl.float32)
    r0: tl.constexpr = (RH + PH) % 2 if PARITY else 0
    s0: tl.constexpr = (RW + PW) % 2 if PARITY else 0
    for r in range(r0, R, scale):
        for s in range(s0, S, scale):
            hp = iy + PH - r * DH
            wp = ix + PW - s * DW
            py = hp // SH
            px = wp // SW
            ok = (n < B * rows * cols) & (hp >= 0) & (wp >= 0) & (py < P) & (px < Q)
            if not PARITY:
                ok = ok & (hp % SH == 0) & (wp % SW == 0)
            for k in range(tl.cdiv(O, BK)):
                oc = k * BK + kk
                wt = tl.load(w_group + oc[None, :] * C * R * S + ci[:, None] * R * S + r*S+s,
                             (ci[:, None] < C) & (oc[None, :] < O), 0)
                dy = tl.load(D + dy_sample[None, :] + oc[:, None] * P * Q + py[None, :]*Q + px[None, :],
                             (oc[:, None] < O) & ok[None, :], 0)
                acc = tl.dot(wt, dy, acc, input_precision="ieee")
    dst = ((outer * B + batch) * I + inner) * C * H * W + iy * W + ix
    tl.store(DX + dst[None, :] + ci[:, None] * H * W, acc,
             (ci[:, None] < C) & (n[None, :] < B * rows * cols))


@triton.jit
def _dx(D, WT, DX, B: tl.constexpr, C: tl.constexpr, O: tl.constexpr,
        H: tl.constexpr, W: tl.constexpr, P: tl.constexpr, Q: tl.constexpr,
        R: tl.constexpr, S: tl.constexpr, SH: tl.constexpr, SW: tl.constexpr,
        PH: tl.constexpr, PW: tl.constexpr, DH: tl.constexpr, DW: tl.constexpr,
        I: tl.constexpr, PARITY: tl.constexpr, BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    if PARITY:
        for phase in tl.static_range(4):
            if tl.program_id(2) == phase:
                _dx_tile(D, WT, DX, B,C,O,H,W,P,Q,R,S,SH,SW,PH,PW,DH,DW,I,
                         True,phase//2,phase%2,BM,BN,BK)
    else:
        _dx_tile(D, WT, DX, B,C,O,H,W,P,Q,R,S,SH,SW,PH,PW,DH,DW,I,False,0,0,BM,BN,BK)


@triton.jit
def _dw_db(X, D, DWOUT, DBOUT, B: tl.constexpr, C: tl.constexpr, O: tl.constexpr,
           H: tl.constexpr, W: tl.constexpr, P: tl.constexpr, Q: tl.constexpr,
           R: tl.constexpr, S: tl.constexpr, SH: tl.constexpr, SW: tl.constexpr,
           PH: tl.constexpr, PW: tl.constexpr, DH: tl.constexpr, DW: tl.constexpr,
           I: tl.constexpr, PARTS: tl.constexpr, BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    tile = tl.program_id(0)
    task = tl.program_id(1).to(tl.int64)
    part = tl.program_id(2)
    outer = task // I
    inner = task % I
    # RGB stems use one flat CRS tile. Other layers use a fixed tap so both
    # input and dy read adjacent spatial positions for stride=1.
    if C < 16:
        nc: tl.constexpr = tl.cdiv(C*R*S, BN)
        crs = tile % nc * BN + tl.arange(0, BN)
        ci = crs // (R*S)
        rr = crs // S % R
        ss = crs % S
        oc = tile // nc * BM + tl.arange(0, BM)
        owner = tile % nc == 0
    else:
        nc: tl.constexpr = tl.cdiv(C, BN)
        tap = tile % (nc*R*S) // nc
        ci = tile % nc * BN + tl.arange(0, BN)
        crs = ci * (R*S) + tap
        rr = tl.full((BN,), 0, tl.int32) + tap // S
        ss = tl.full((BN,), 0, tl.int32) + tap % S
        oc = tile // (nc*R*S) * BM + tl.arange(0, BM)
        owner = tile % (nc*R*S) == 0
    acc = tl.zeros((BM, BN), tl.float32)
    bias = tl.full((BM,), 0, tl.float32)
    kk = tl.arange(0, BK)
    blocks: tl.constexpr = tl.cdiv(B*P*Q, BK*PARTS)
    # Limit the length of a sequential FP32 dot accumulator at large B.
    group_blocks: tl.constexpr = 8 if blocks >= 32 else 1
    for chunk in range(tl.cdiv(blocks, group_blocks)):
        partial = tl.zeros((BM, BN), tl.float32)
        for j in range(group_blocks):
            k = ((chunk*group_blocks+j)*PARTS+part)*BK+kk
            b = (k // (P*Q)).to(tl.int64)
            py = k // Q % P
            px = k % Q
            sample = (outer * B + b) * I + inner
            dy = tl.load(D + sample[None, :]*O*P*Q + oc[:, None]*P*Q + (k % (P*Q))[None, :],
                         (k[None, :] < B*P*Q) & (oc[:, None] < O), 0)
            iy = py[:, None]*SH-PH+rr[None, :]*DH
            ix = px[:, None]*SW-PW+ss[None, :]*DW
            x = tl.load(X + sample[:, None]*C*H*W + ci[None, :]*H*W + iy*W+ix,
                        (k[:, None] < B*P*Q) & (ci[None, :] < C)
                        & (iy >= 0) & (iy < H) & (ix >= 0) & (ix < W), 0)
            if group_blocks == 1:
                acc = tl.dot(dy, x, acc, input_precision="ieee")
            else:
                partial = tl.dot(dy, x, partial, input_precision="ieee")
            if owner:
                bias += tl.sum(dy, 1)
        if group_blocks != 1:
            acc += partial
    out = task * PARTS + part
    tl.store(DWOUT + out*O*C*R*S + oc[:, None]*C*R*S + crs[None, :], acc,
             (oc[:, None] < O) & (crs[None, :] < C*R*S))
    if owner:
        tl.store(DBOUT + out*O + oc, bias, oc < O)


@triton.jit
def _finish(WP, BP, WT, BT, NW: tl.constexpr, NO: tl.constexpr, PARTS: tl.constexpr, TILE: tl.constexpr):
    task = tl.program_id(1).to(tl.int64)
    pid = tl.program_id(0)
    p = tl.arange(0, PARTS)
    lane = tl.arange(0, TILE)
    if pid < tl.cdiv(NW, TILE):
        i = pid*TILE + lane
        v = tl.load(WP + (task*PARTS+p[:, None])*NW+i[None, :], i[None, :] < NW, 0)
        tl.store(WT+task*NW+i, tl.sum(v, 0), i < NW)
    else:
        i = (pid-tl.cdiv(NW,TILE))*TILE+lane
        v = tl.load(BP + (task*PARTS+p[:, None])*NO+i[None, :], i[None, :] < NO, 0)
        tl.store(BT+task*NO+i, tl.sum(v, 0), i < NO)


def _pair(value):
    try:
        n = operator.index(value)
    except TypeError:
        values = tuple(map(operator.index, value))
        if len(values) != 2:
            raise ValueError("expected an integer or a pair of integers")
        return values
    return n, n


def _parts(tasks, b, c, o, r, s, p, q, sms):
    tiles = tasks * triton.cdiv(o, 32) * (triton.cdiv(c*r*s,32) if c < 16 else r*s*triton.cdiv(c,32))
    length = b*p*q
    want = max(triton.cdiv(2*sms, tiles), triton.cdiv(length, 2048))
    cap = min(128, max(1,length//128), (128 << 20)//(tasks*o*(c*r*s+1)*4))
    return 1 << (max(1,min(want,cap)).bit_length()-1)


def _backward(x, weight, grad_output, stride, padding, dilation, groups, algorithm):
    lifted = x.ndim == 4
    if lifted and weight.ndim == grad_output.ndim == 4:
        x, weight, grad_output = (a.unsqueeze(0) for a in (x,weight,grad_output))
    if x.ndim != 5 or weight.ndim != 5 or grad_output.ndim != 5:
        raise ValueError("all three inputs must be 5D group-first or all 4D NCHW")
    if not x.is_cuda or x.dtype != torch.float32 or any(
            t.device != x.device or t.dtype != x.dtype for t in (weight,grad_output)):
        raise ValueError("expected FP32 tensors on one CUDA device")
    g,b,channels,h,w = x.shape
    gw,o_total,c,r,s = weight.shape
    i = operator.index(groups)
    # Also accept the conventional groups=G spelling for a full per-group filter.
    if not lifted and i == g and c == channels:
        i = 1
    sh,sw = _pair(stride)
    ph,pw = _pair(padding)
    dh,dw = _pair(dilation)
    if min(g,b,c,o_total,h,w,r,s,sh,sw,dh,dw,i) < 1 or min(ph,pw) < 0:
        raise ValueError("invalid convolution dimensions or parameters")
    if gw != g or channels != i*c or o_total % i:
        raise ValueError("weight or groups incompatible with input channels")
    o = o_total // i
    p = (h+2*ph-dh*(r-1)-1)//sh+1
    q = (w+2*pw-dw*(s-1)-1)//sw+1
    if min(p,q) < 1 or tuple(grad_output.shape) != (g,b,o_total,p,q):
        raise ValueError("grad_output does not match the forward output shape")
    if g*i > 65535 or max(b*h*w,b*p*q,channels*h*w,o_total*p*q,o*c*r*s) >= 2**31-4096:
        raise ValueError("per-group dimensions exceed kernel indexing limits")
    if algorithm not in ("auto","direct","winograd"):
        raise ValueError("unknown algorithm")
    eligible = (i == 1 and (r,s,sh,sw,dh,dw,ph,pw) == (3,3,1,1,1,1,1,1)
                and winograd_fits(g,b,c,o,h,w))
    if algorithm == "winograd" and not eligible:
        raise ValueError("Winograd requires dense 3x3 s1 p1 d1 and <=2048 tiles/group, <=128 MiB scratch")
    use_win = eligible and (algorithm == "winograd" or
                            (algorithm == "auto" and min(c,o) >= 32
                             and 16 <= b*triton.cdiv(h,2)*triton.cdiv(w,2) <= 1024))
    with torch.cuda.device(x.device):
        x, weight, dy = (t.contiguous() for t in (x,weight,grad_output))
        dx, dw_out = torch.empty_like(x), torch.empty_like(weight)
        db = x.new_empty((g,o_total))
        if use_win:
            winograd_backward(x, weight, dy, dx, dw_out, db)
        else:
            dims = (b,c,o,h,w,p,q,r,s,sh,sw,ph,pw,dh,dw,i)
            parity = (r,s,sh,sw,dh,dw) == (3,3,2,2,1,1) and min(h,w) >= 2
            scale = 2 if parity else 1
            count = b*triton.cdiv(h,scale)*triton.cdiv(w,scale)
            bm = 16 if c < 32 else 32
            bn = 32
            _dx[(triton.cdiv(c,bm)*triton.cdiv(count,bn),g*i,scale*scale)](
                dy,weight,dx,*dims,parity,bm,bn,16,num_warps=4)
            parts = _parts(g*i,b,c,o,r,s,p,q,torch.cuda.get_device_properties(x.device).multi_processor_count)
            wp = dw_out if parts == 1 else x.new_empty((g*i,parts,o,c,r,s))
            bp = db if parts == 1 else x.new_empty((g*i,parts,o))
            tiles = triton.cdiv(c*r*s,32) if c < 16 else triton.cdiv(c,32)*r*s
            _dw_db[(triton.cdiv(o,32)*tiles,g*i,parts)](
                x,dy,wp,bp,*dims,parts,32,32,32,num_warps=4)
            if parts > 1:
                nw = o*c*r*s
                _finish[(triton.cdiv(nw,64)+triton.cdiv(o,64),g*i)](wp,bp,dw_out,db,nw,o,parts,64)
    outputs = (dx,dw_out,db)
    return tuple(t.squeeze(0) for t in outputs) if lifted else outputs


def conv_bwd(x, weight, grad_output, stride=1, padding=1, dilation=1, groups=1):
    """Return (dx, dw, db) for [G,B,C,H,W], [G,O,C/groups,R,S], [G,B,O,P,Q].

    Outer G is inferred. With full per-group weights, groups=G is also accepted.
    With a 4D input the usual PyTorch groups semantics apply. Manual derivative:
    outputs do not create an autograd graph. Inputs are never mutated.
    """
    return _backward(x,weight,grad_output,stride,padding,dilation,groups,"auto")
