"""Extended shape suite, paired timing, explicit failure/skip rows and stage diagnostics."""
import argparse,gc,hashlib,itertools,json,random,statistics,time
from pathlib import Path
import torch,triton
import conv_double_bwd as kernel
from conv_double_bwd import convolution_double_backward as custom,workspace_split


BASELINES={}

def baseline_key(row):
    return tuple(row[k] for k in ('G','F','C','O','H','W','R','S','stride','padding','dilation','bias'))


def load_baseline(path,meta,a):
    env=None;rows=[]
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        if line.startswith('ENV '):env=json.loads(line[4:])
        elif line.startswith('RESULT '):
            try:r=json.loads(line[7:])
            except json.JSONDecodeError:continue
            if r.get('status')=='ok':rows.append(r)
    if env is None:raise ValueError('ATen baseline has no ENV header')
    for key in ('torch','cuda','cudnn','gpu'):
        if env.get(key)!=meta.get(key):raise ValueError('ATen baseline environment mismatch: '+key)
    if a.dtype!='fp32' or a.precision!='ieee':raise ValueError('Saved baseline reuse currently requires FP32 IEEE')
    if env.get('dtype')!='fp32' or env.get('precision')!='ieee':raise ValueError('Baseline precision mismatch')
    flags=env.get('args',{})
    if flags.get('dtype','fp32')!='fp32' or flags.get('precision','ieee')!='ieee':raise ValueError('Baseline precision mismatch')
    if env.get('tf32',False) or env.get('cudnn_benchmark',True)!=True:raise ValueError('Baseline backend settings mismatch')
    BASELINES.clear()
    for row in rows:BASELINES[baseline_key(row)]=row
    print(f'Reusing {len(BASELINES)} ATen baseline configurations; only Triton is timed.',flush=True)


def cases(models=('conv3','resnet18'),datasets=('cifar10','imagenet'),imagenet_sizes=(128,224),stem='auto',width=128):
    result=[]
    for dataset in datasets:
        for size in ([32] if dataset=='cifar10' else imagenet_sizes):
            for model in models:
                variants=['small'] if model=='conv3' else (['small' if dataset=='cifar10' else 'standard'] if stem=='auto' else ['small','standard'] if stem=='both' else [stem])
                for variant in variants:
                    prefix=f'{model}_{dataset}_{size}_{variant}'
                    layers=[]
                    def add(name,c,o,h,k=3,stride=1,pad=1,bias=False):
                        layers.append(dict(name=name,C=c,O=o,H=h,W=h,R=k,S=k,stride=stride,padding=pad,dilation=1,bias=bias))
                        return (h+2*pad-k)//stride+1
                    if model=='conv3':
                        h=size
                        for n in range(3):
                            add(f'conv{n+1}',3 if n==0 else width,width,h,bias=True)
                            if n<2:h//=2
                    else:
                        h=add('stem',3,64,size,k=7 if variant=='standard' else 3,stride=2 if variant=='standard' else 1,pad=3 if variant=='standard' else 1)
                        if variant=='standard':h=(h+2-3)//2+1
                        c=64
                        for stage,o in enumerate((64,128,256,512)):
                            for block in range(2):
                                st=2 if stage>0 and block==0 else 1
                                old=h
                                h=add(f's{stage+1}b{block+1}_conv1',c,o,h,stride=st)
                                add(f's{stage+1}b{block+1}_conv2',o,o,h)
                                if st!=1 or c!=o:add(f's{stage+1}b{block+1}_shortcut',c,o,old,k=1,stride=st,pad=0)
                                c=o
                    # Deduplicate equivalent shapes, preserve layer names/count for weighted summaries.
                    unique={}
                    for layer in layers:
                        key=tuple(v for k,v in layer.items() if k!='name')
                        if key not in unique: unique[key]=dict(layer,layers=[layer['name']],multiplicity=1)
                        else:unique[key]['layers'].append(layer['name']);unique[key]['multiplicity']+=1
                    for j,layer in enumerate(unique.values()):
                        result.append(dict(case=f'{prefix}_{j}_{layer["name"]}',model=model,dataset=dataset,image_size=size,stem=variant,**layer))
    return result

def pack(t):
    if t is None: return None
    g,f,c,h,w=t.shape
    return t.permute(1,0,2,3,4).reshape(f,g*c,h,w).contiguous()


def unpack(t,g):
    if t is None: return None
    f,gc,h,w=t.shape
    return t.reshape(f,g,gc//g,h,w).permute(1,0,2,3,4).contiguous()


def prepare_aten(args):
    ai,aw,ab,d,w,x,st,pad,dil,trans,op,inner,mask=args
    g=x.shape[0]
    return (pack(ai),None if aw is None else aw.flatten(0,1),
            None if ab is None else ab.flatten(),pack(d),w.flatten(0,1),pack(x),
            st,pad,dil,trans,op,g,mask)


def aten_group_first(args):
    g=args[5].shape[0]
    a,b,c=torch.ops.aten._convolution_double_backward(*prepare_aten(args))
    return unpack(a,g),unpack(b,g),None if c is None else c.reshape(args[4].shape).contiguous()


def make_args(shape,dtype,device,st=(1,1),pad=(1,1),dil=(1,1),opts=(True,True,True),mask=(True,True,True)):
    g,f,c,o,h,w,r,s=shape
    p=(h+2*pad[0]-dil[0]*(r-1)-1)//st[0]+1
    q=(w+2*pad[1]-dil[1]*(s-1)-1)//st[1]+1
    def rand(*a): return torch.randn(*a,device=device,dtype=dtype)
    x=rand(g,f,c,h,w); wt=rand(g,o,c,r,s); d=rand(g,f,o,p,q)
    ai=rand(*x.shape) if opts[0] else None
    aw=rand(*wt.shape) if opts[1] else None
    ab=rand(g,o) if opts[2] else None
    return (ai,aw,ab,d,wt,x,list(st),list(pad),list(dil),False,[0,0],1,list(mask))


def compare(args,precision,split=None,budget=32,algorithm="auto"):
    got=custom(*args,precision=precision,split_k=split,workspace_limit_mb=budget,algorithm=algorithm)
    ref=aten_group_first(args)
    return check(got,ref,args[5].dtype,precision,args=args)


def correctness(dtype,precision):
    count=0
    cases=[((2,2,17,33,7,9,3,3),(1,1),(1,1),(1,1)),
           ((2,2,32,64,9,11,3,3),(2,2),(1,1),(1,1)),
           ((1,1,3,64,17,17,7,7),(2,2),(3,3),(1,1)),
           ((2,2,3,17,9,11,3,3),(1,1),(1,1),(1,1)),
           ((3,2,5,7,10,11,3,2),(2,1),(2,1),(2,1)),
           ((2,1,33,65,4,5,1,1),(1,1),(0,0),(1,1)),
           ((2,1000,2,3,4,4,3,3),(1,1),(1,1),(1,1))]
    for shape,st,pad,dil in cases:
        args=make_args(shape,dtype,'cuda',st,pad,dil)
        for sk in (1,4):
            print('check',shape,'split',sk,compare(args,precision,sk),flush=True); count+=1
    # All optional-input combinations and a false mask: mirrors ATen 2.5.1.
    for opts in itertools.product((False,True),repeat=3):
        args=make_args((2,2,3,7,5,6,3,3),dtype,'cuda',opts=opts)
        print('optional',opts,compare(args,precision,1),flush=True); count+=1
    args=make_args((2,2,3,7,5,6,3,3),dtype,'cuda',mask=(False,False,False))
    print('ATen output_mask compatibility',compare(args,precision,1),flush=True); count+=1
    if dtype==torch.float32:
        for shape,pad in [((2,2,17,33,7,9,3,3),(1,1)),((2,3,32,64,6,7,3,3),(0,2)),((2,10,128,128,16,16,3,3),(1,1))]:
            args=make_args(shape,dtype,'cuda',pad=pad)
            print('Packed Winograd forced',shape,compare(args,precision,algorithm='winograd'),flush=True);count+=1
        for shape,budget in [((5,2,3,7,5,6,3,3),.06),((2,35,3,7,4,5,3,3),.02)]:
            args=make_args(shape,dtype,'cuda')
            print('Packed group/tile tail',shape,compare(args,precision,budget=budget,algorithm='winograd'),flush=True);count+=1
        for opts in itertools.product((False,True),repeat=3):
            args=make_args((2,2,3,7,5,6,3,3),dtype,'cuda',opts=opts)
            print('Packed Winograd optional',opts,compare(args,precision,algorithm='winograd'),flush=True);count+=1
    if dtype==torch.float32:
        for sk in (1,2,4):
            args=make_args((3,35,17,33,7,9,3,3),dtype,'cuda')
            print('V8 joint split',sk,compare(args,precision,split=sk,budget=1,algorithm='winograd_joint'),flush=True);count+=1
        args=make_args((2,3,17,33,7,9,3,3),dtype,'cuda')
        ref=aten_group_first(args)
        for i in range(3):
            flags=tuple(j==i for j in range(3))
            got=custom(*args,precision=precision,algorithm='winograd',compute=flags)
            print('V8 isolated stage',i,check(got,tuple(ref[j] if j==i else None for j in range(3)),dtype,precision,args=args),flush=True);count+=1
    if dtype==torch.float32:
        for alg in ('winograd_separate','winograd_joint','winograd_v6'):
            args=make_args((3,5,17,33,7,9,3,3),dtype,'cuda',pad=(0,2))
            print('Schedule check',alg,compare(args,precision,budget=1,algorithm=alg),flush=True);count+=1
    if dtype==torch.float32:
        args=make_args((2,1000,2,3,4,4,3,3),dtype,'cuda')
        print('V8 long reduction',compare(args,precision,budget=.1,split=2,algorithm='winograd_joint'),flush=True);count+=1
    if dtype==torch.float32:
        for shape in ((5,3,33,17,7,9,3,3),(8,1,17,33,7,9,3,3),(2,3,128,128,8,8,3,3)):
            args=make_args(shape,dtype,'cuda')
            print('V8 fused ggO',shape,compare(args,precision,budget=4,algorithm='winograd'),flush=True);count+=1
        args=make_args((3,2,5,7,5,6,3,3),dtype,'cuda')
        providers,singles=serial_providers(args,dict(precision=precision,algorithm='winograd',workspace_limit_mb=1))
        validate_serial(providers,singles,dtype,precision)
        print('PASS serial baselines use distinct group slices',flush=True);count+=1
    correctness_large(dtype,precision)
    print(f'PASS: {count} GPU cases; compared directly with aten._convolution_double_backward',flush=True)


def correctness_large(dtype,precision):
    if dtype!=torch.float32:raise ValueError('Large Winograd path requires fp32')
    count=0
    if dtype==torch.float32:
        for shape,budget,sk in [((3,137,17,33,7,9,3,3),4,None),
                                ((2,1000,2,3,4,4,3,3),1,None),
                                ((3,35,33,17,7,9,3,3),.1,2),
                                ((2,100,128,128,16,16,3,3),128,None),
                                ((2,100,64,64,32,32,3,3),128,None)]:
            args=make_args(shape,dtype,'cuda')
            print('V9 large/tail',shape,compare(args,precision,budget=budget,split=sk,algorithm='winograd_large'),flush=True);count+=1
        for opts in itertools.product((False,True),repeat=3):
            args=make_args((2,3,5,7,5,6,3,3),dtype,'cuda',opts=opts)
            print('V9 optional',opts,compare(args,precision,budget=1,algorithm='winograd_large'),flush=True);count+=1
        args=make_args((2,5,17,33,7,9,3,3),dtype,'cuda',pad=(0,2))
        ref=aten_group_first(args)
        for i in range(3):
            flags=tuple(j==i for j in range(3))
            got=custom(*args,precision=precision,algorithm='winograd_large',workspace_limit_mb=1,compute=flags)
            print('V9 isolated stage',i,check(got,tuple(ref[j] if j==i else None for j in range(3)),dtype,precision,args=args),flush=True);count+=1
    print(f'PASS: {count} V9 GPU cases; compared directly with ATen',flush=True)


class ValidationError(AssertionError):
    def __init__(self,details):
        self.details=details
        super().__init__(json.dumps(details,ensure_ascii=False))


def fp64_gw_samples(args,indices,got,ref):
    # Vectorized independent direct FP64 sums. Scratch is bounded by 16*4096 entries.
    ai,_,_,d,wt,x,st,pad,dil,*_=args
    g,f,c,h,w=x.shape; _,o,_,r,s=wt.shape; p,q=d.shape[-2:]
    out=[];aa=got.reshape(-1);bb=ref.reshape(-1)
    for off in range(0,len(indices),16):
        ids=torch.tensor(indices[off:off+16],device=x.device,dtype=torch.long)
        j=ids;ss=j%s;j=j//s;rr=j%r;j=j//r;ci=j%c;j=j//c;oc=j%o;gg=j//o
        total=torch.zeros(len(ids),device=x.device,dtype=torch.float64)
        for begin in range(0,f*p*q,4096):
            k=torch.arange(begin,min(begin+4096,f*p*q),device=x.device)[None,:]
            ff=k//(p*q);py=k//q%p;qx=k%q
            ih=py*st[0]-pad[0]+rr[:,None]*dil[0];iw=qx*st[1]-pad[1]+ss[:,None]*dil[1]
            valid=(ih>=0)&(ih<h)&(iw>=0)&(iw<w)
            v=ai[gg[:,None],ff,ci[:,None],ih.clamp(0,h-1),iw.clamp(0,w-1)].double()
            total+=(v*d[gg[:,None],ff,oc[:,None],py,qx].double()*valid).sum(dim=1)
        for index,oracle,custom_val,aten_val in zip(ids.tolist(),total.tolist(),aa[ids].tolist(),bb[ids].tolist()):
            out.append(dict(index=index,fp64=oracle,triton=custom_val,aten=aten_val,
                            triton_abs_error=abs(custom_val-oracle),aten_abs_error=abs(aten_val-oracle)))
    return out


def check(got,ref,dtype,precision,args=None):
    atol,rtol,lim={torch.float32:(.003,.002,2e-4),torch.float16:(.08,.02,.003),torch.bfloat16:(.6,.08,.02)}[dtype]
    if dtype==torch.float32 and precision=='tf32':atol,rtol,lim=.1,.03,.004
    out={};failures=[]
    for name,x,y in zip(('ggO','gI','gW'),got,ref):
        if x is None or y is None:
            assert x is y is None,(name,'None mismatch');continue
        assert x.shape==y.shape,(name,'shape mismatch')
        xx=x.reshape(-1); yy=y.reshape(-1)
        ds=ys=mx=0.;mismatches=0;bad_indices=[]
        for begin in range(0,x.numel(),262144):
            a=xx[begin:begin+262144]; b=yy[begin:begin+262144]
            d=a.double()-b.double(); ds+=d.square().sum().item(); ys+=b.double().square().sum().item()
            mx=max(mx,d.abs().max().item())
            bad=~torch.isclose(a,b,atol=atol,rtol=rtol)
            mismatches+=bad.sum().item()
            if len(bad_indices)<4097:
                bad_indices.extend((bad.nonzero().flatten()[:4097-len(bad_indices)]+begin).tolist())
        rel=(ds/max(ys,1e-60))**.5
        out[name+'_max_abs']=mx;out[name+'_rel_l2']=rel
        if mismatches or not rel<=lim:
            failure=dict(output=name,shape=list(x.shape),mismatches=mismatches,numel=x.numel(),
                         max_abs=mx,rel_l2=rel,atol=atol,rtol=rtol,rel_l2_limit=lim,first_bad_indices=bad_indices[:8])
            if name=='gW' and args is not None and 0<mismatches<=4096 and rel<=lim:
                rng=random.Random(73021)
                indices=sorted(set(bad_indices+rng.sample(range(x.numel()),min(64,x.numel()))))
                samples=fp64_gw_samples(args,indices,x,y)
                oracle_ok=all(v['triton_abs_error']<=atol+rtol*abs(v['fp64']) for v in samples)
                failure['fp64_checked']=len(samples);failure['fp64_samples']=samples[:8]
                if oracle_ok:
                    out['gW_validation']='fp64_resolved'
                    out['gW_aten_mismatches']=mismatches
                    out['gW_fp64_checked']=len(samples)
                    out['gW_fp64_max_abs']=max(v['triton_abs_error'] for v in samples)
                    out['gW_aten_fp64_max_abs']=max(v['aten_abs_error'] for v in samples)
                    continue
            failures.append(failure)
    if failures:raise ValidationError(dict(metrics=out,failures=failures))
    return out


def once(fn,n):
    start=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True)
    torch.cuda.synchronize(); t=time.perf_counter(); start.record()
    for _ in range(n):
        result=fn()
        del result
    end.record();end.synchronize()
    return start.elapsed_time(end)/n,(time.perf_counter()-t)*1000/n


def stats(values):
    mean=statistics.mean(values)
    return dict(mean=mean,median=statistics.median(values),min=min(values),max=max(values),
                cv_pct=100*statistics.stdev(values)/mean if len(values)>1 and mean else 0)


def paired(funcs,a):
    counts={}; raw={k:dict(event=[],wall=[]) for k in funcs}
    for name,fn in funcs.items():
        print('  preparing',name,flush=True)
        for _ in range(a.warmup):fn()
        torch.cuda.synchronize(); t=time.perf_counter()
        while (time.perf_counter()-t)*1000<a.warmup_ms:
            fn();torch.cuda.synchronize()
        probe,_=once(fn,3)
        counts[name]=max(2,min(a.iters,int(a.target_ms/max(probe,.001))))
    rng=random.Random(123)
    for repeat in range(a.rounds):
        order=list(funcs);rng.shuffle(order)
        for name in order:
            ev,wall=once(funcs[name],counts[name]);raw[name]['event'].append(ev);raw[name]['wall'].append(wall)
    out={}
    for name,fn in funcs.items():
        out[name+'_iters']=counts[name]
        for mode in ('event','wall'):
            out[name+'_'+mode+'_rounds']=json.dumps(raw[name][mode])
            for k,val in stats(raw[name][mode]).items():out[name+'_'+mode+'_'+k]=val
        torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();base=torch.cuda.memory_allocated()
        val=fn();torch.cuda.synchronize();out[name+'_peak_extra_bytes']=torch.cuda.max_memory_allocated()-base;del val
    return out


def summarize_cuda_events(events,repeats):
    """Use only device events: CPU-parent CUDA totals would double-count kernels.
    Union time is observed CUDA activity coverage, NOT SM utilization. Profiler
    overhead can enlarge gaps, so these timings are not benchmark speedups.
    """
    groups={};intervals=[];families={}
    known=('_pack_pair9','_weight_pair9','_packed_dual8','_pack_dout7','_packed_gw7','_packed_conv7','_pack_tiles_all','_packed_gw_acc','_packed_conv','_packed_gw','_pack_tiles','_win_weight_pack',
           '_win_gw_out','_win_out','_accumulate','_ggo','_gi','_gw','_reduce')
    for e in events:
        if str(e.device_type).split('.')[-1]!='CUDA':continue
        start=float(e.time_range.start);end=float(e.time_range.end)
        if end<start:continue
        name=e.name;duration=end-start
        intervals.append((start,end))
        rec=groups.setdefault(name,dict(name=name,calls=0,total_us=0.))
        rec['calls']+=1;rec['total_us']+=duration
        family=next((k for k in known if name==k or name.startswith(k+'_')), 'other_cuda')
        fam=families.setdefault(family,dict(name=family,calls=0,total_us=0.))
        fam['calls']+=1;fam['total_us']+=duration
    if not intervals:
        return dict(status='unavailable',reason='No CUDA device events: CUPTI/Kineto tracing unavailable; normal benchmark is still valid.')
    intervals.sort();left,right=intervals[0];union=0.
    for start,end in intervals[1:]:
        if start>right:union+=right-left;left,right=start,end
        else:right=max(right,end)
    union+=right-left;span=max(b for _,b in intervals)-intervals[0][0]
    total=sum(r['total_us'] for r in groups.values())
    def finish(records):
        result=[]
        for r in sorted(records.values(),key=lambda r:r['total_us'],reverse=True):
            result.append(dict(name=r['name'],calls_per_api=r['calls']/repeats,
                ms_per_api=r['total_us']/repeats/1000,mean_us=r['total_us']/r['calls'],
                activity_share_pct=100*r['total_us']/total if total else 0.))
        return result
    return dict(status='ok',repeats=repeats,activity_ms_per_api=total/repeats/1000,
                timeline_span_ms_per_api=span/repeats/1000,
                uncovered_span_pct=100*(span-union)/span if span else 0.,
                families=finish(families),kernels=finish(groups))


def profile_callable(fn,repeats):
    # All compilation/autotuning and regular timing have finished before entry.
    from torch.profiler import profile,ProfilerActivity
    for _ in range(3):fn()
    torch.cuda.synchronize()
    with profile(activities=[ProfilerActivity.CPU,ProfilerActivity.CUDA],
                 record_shapes=False,profile_memory=False,with_stack=False) as prof:
        for _ in range(repeats):
            val=fn()
            del val
        torch.cuda.synchronize()
    result=summarize_cuda_events(prof.events(),repeats)
    result['note']='Instrumented trace only; CUDA activity span gaps are not SM utilization or a pure CPU-overhead measurement.'
    return result


def graph_probe(fn,a):
    """Diagnostic only: capture/allocation excluded, static outputs retained.
    Apply equally to Triton and ATen. Does not change production dispatch.
    """
    stream=torch.cuda.Stream();stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        for _ in range(3):fn()
    torch.cuda.current_stream().wait_stream(stream);torch.cuda.synchronize()
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph,stream=stream):held=fn()
    graph.replay();torch.cuda.synchronize()
    reference=fn();torch.cuda.synchronize()
    for actual,expected in zip(held,reference):
        if actual is None or expected is None:
            if actual is not expected:raise AssertionError('Graph optional output mismatch')
        else:torch.testing.assert_close(actual,expected,rtol=.002,atol=.003)
    del reference
    for _ in range(a.warmup):graph.replay()
    probe,_=once(graph.replay,3)
    n=max(2,min(a.iters,int(a.target_ms/max(probe,.001))))
    values=[once(graph.replay,n)[0] for _ in range(a.rounds)]
    return dict(status='ok',event_ms=stats(values),iters=n,
                note='Replay only; static outputs, capture and allocations excluded. Not an eager API replacement.')


def split_group_args(args):
    # Views prepared outside timing. Each group receives its own original values.
    return [tuple(None if t is None else t[i:i+1] for t in args[:6])+tuple(args[6:])
            for i in range(args[5].shape[0])]


def serial_providers(args,kw):
    singles=split_group_args(args)
    ready=[prepare_aten(one) for one in singles]
    def serial_triton():
        # Retain every group's outputs until the full G-group task is complete.
        return [custom(*one,**kw) for one in singles]
    def serial_aten():
        return [torch.ops.aten._convolution_double_backward(*one) for one in ready]
    return dict(serial_triton=serial_triton,serial_aten=serial_aten),singles


def validate_serial(providers,singles,dtype,precision):
    # No concatenation or validation is included in timed serial work.
    for name,fn in providers.items():
        results=fn()
        for one,got in zip(singles,results):
            if name=='serial_aten':got=tuple(None if t is None else t.unsqueeze(0) for t in got)
            check(got,aten_group_first(one),dtype,precision,args=one)
        del results


def scaling_metrics(row,g,f):
    t=row['triton_event_median'];sa=row['serial_aten_event_median'];st=row['serial_triton_event_median']
    return dict(serial_aten_over_fused_triton=sa/t,serial_triton_over_fused_triton=st/t,
                serial_aten_over_grouped_aten=sa/row['aten_prepacked_event_median'],
                serial_aten_over_serial_triton=sa/st,
                fusion_efficiency_pct=100*st/t/g,
                group_images_per_second=g*f*1000/t,
                serial_triton_group_images_per_second=g*f*1000/st,
                scaling_stable=max(row[k+'_event_cv_pct'] for k in ('triton','serial_aten','serial_triton','aten_prepacked'))<=5)


def run(case,g,f,a):
    c,o,h,w,r,s=(case[k] for k in ('C','O','H','W','R','S'))
    st,pad,dil=(case[k] for k in ('stride','padding','dilation'))
    p=(h+2*pad-dil*(r-1)-1)//st+1;q=(w+2*pad-dil*(s-1)-1)//st+1
    nx=g*f*c*h*w;nd=g*f*o*p*q;nw=g*o*c*r*s
    dtype={'fp32':torch.float32,'fp16':torch.float16,'bf16':torch.bfloat16}[a.dtype]
    item=4 if dtype==torch.float32 else 2
    row=dict(case,G=g,F=f,B=f,P=p,Q=q,status='pending')
    if a.aten_baseline and baseline_key(row) not in BASELINES:
        return dict(row,status='skip_missing_baseline',error='No measured matching baseline; no automatic retiming')
    # Conservative estimate, not a promise of fitting cuDNN workspaces.
    estimate=item*(7*nx+6*nd+6*nw)+int(a.workspace_mb*1024**2)+32*1024**2
    row['estimated_bytes']=estimate
    free,_=torch.cuda.mem_get_info()
    if max(nx,nd,nw)>=2**30 or g*f>65535:
        return dict(row,status='skip_index_limit')
    if estimate>free*a.memory_fraction:
        return dict(row,status='skip_memory_estimate',free_bytes=free)
    seed=123+int(hashlib.sha256(str((g,f,c,o,h,w,r,s,st,pad,dil,case['bias'])).encode()).hexdigest()[:8],16)
    torch.manual_seed(seed);row['seed']=seed
    args=make_args((g,f,c,o,h,w,r,s),dtype,'cuda',(st,)*2,(pad,)*2,(dil,)*2,opts=(True,True,case['bias']))
    kw=dict(precision=a.precision,workspace_limit_mb=a.workspace_mb,split_k=a.split_k,algorithm=a.algorithm)
    plan=kernel.winograd_plan(g,f,c,o,h,w,p,q,r,s,st,st,pad,pad,dil,dil,dtype,int(a.workspace_mb*1024**2),a.algorithm,a.split_k)
    ref=aten_group_first(args); got=kernel.convolution_double_backward(*args,**kw)
    row.update(check(got,ref,dtype,a.precision,args=args));del got
    if plan.get('version') in (8,9) and plan.get('joint_nt'):
        row['joint_ggO_config']=str(getattr(kernel._packed_dual8,'best_config','unavailable'))
    if a.stages:
        for i,name in enumerate(('ggO','gI','gW')):
            flags=tuple(j==i for j in range(3))
            val=kernel.convolution_double_backward(*args,**kw,compute=flags)
            check(val,tuple(ref[j] if j==i else None for j in range(3)),dtype,a.precision,args=args);del val
            active=(plan['ggO_nt'],plan['gI_nt'],plan['gW_split'])[i]
            selected=((kernel._packed_conv7 if i<2 else kernel._packed_gw7) if plan.get('version') in (7,8,9) else (kernel._packed_conv if i<2 else (kernel._packed_gw_acc if plan.get('version')==6 else kernel._packed_gw))) if active else (kernel._ggo,kernel._gi,kernel._gw)[i]
            row[name+'_config']=str(getattr(selected,'best_config','unavailable'))
    del ref
    ready=prepare_aten(args) if not a.aten_baseline else None
    funcs={'triton':lambda:kernel.convolution_double_backward(*args,**kw),
           'aten_prepacked':lambda:torch.ops.aten._convolution_double_backward(*ready),
           'aten_e2e':lambda:aten_group_first(args)}
    if a.compare_schedules:
        for alg in ('winograd_joint','winograd_separate'):
            alt=dict(kw,algorithm=alg)
            funcs[alg]=lambda alt=alt:kernel.convolution_double_backward(*args,**alt)
            check(funcs[alg](),aten_group_first(args),dtype,a.precision,args=args)
    if a.compare_v8:
        funcs['triton_v8']=lambda:kernel.convolution_double_backward(*args,**dict(kw,algorithm='winograd_v8'))
    if a.compare_v7:
        funcs['triton_v7']=lambda:kernel.convolution_double_backward(*args,**dict(kw,algorithm='winograd_v7'))
    if a.compare_v6:
        funcs['triton_v6']=lambda:kernel.convolution_double_backward(*args,**dict(kw,algorithm='winograd_v6'))
    if a.compare_v5:
        funcs['triton_v5']=lambda:kernel.convolution_double_backward(*args,**dict(kw,algorithm='winograd_v5'))
    if a.compare_implicit and a.algorithm!='implicit':
        implicit_kw=dict(kw,algorithm='implicit')
        funcs['triton_implicit']=lambda:kernel.convolution_double_backward(*args,**implicit_kw)
    if a.stages:
        for i,name in enumerate(('ggO','gI','gW')):
            flags=tuple(j==i for j in range(3))
            funcs['stage_'+name]=lambda flags=flags:kernel.convolution_double_backward(*args,**kw,compute=flags)
    if a.scaling:
        serial,singles=serial_providers(args,kw)
        validate_serial(serial,singles,dtype,a.precision)
        funcs.update(serial)
    cached=BASELINES.get(baseline_key(row)) if a.aten_baseline else None
    if a.aten_baseline:
        # ATen was called above only to validate outputs, not for timing.
        funcs.pop('aten_prepacked');funcs.pop('aten_e2e')
    row.update(paired(funcs,a))
    if cached:
        for old,new in [('grouped_aten','aten_prepacked'),('grouped_e2e','aten_e2e')]:
            for field in ('event_median','wall_median','event_cv_pct','peak_extra_bytes','task_peak_bytes'):
                row[new+'_'+field]=cached[old+'_'+field]
        row['aten_baseline_reused']=True
        row['aten_baseline_source']=str(a.aten_baseline)
        row['serial_aten_baseline_ms']=cached['serial_aten_event_median']
        row['serial_aten_baseline_cv_pct']=cached['serial_aten_event_cv_pct']
        row['best_aten_baseline_ms']=min(cached['serial_aten_event_median'],cached['grouped_aten_event_median'])
        row['best_aten_speedup']=row['best_aten_baseline_ms']/row['triton_event_median']
        stores={t.untyped_storage().data_ptr():t.untyped_storage().nbytes() for t in args[:6] if t is not None}
        row['triton_task_peak_bytes']=sum(stores.values())+row['triton_peak_extra_bytes']

    if a.scaling:
        row.update(scaling_metrics(row,g,f))
        row['scaling_stable']=max(row[k+'_event_cv_pct'] for k in ('triton','serial_aten','serial_triton','aten_prepacked'))<=a.max_cv
        fusion=row['serial_triton_over_fused_triton']
        row['fusion_policy']='unstable' if not row['scaling_stable'] else ('regression' if fusion<.97 else ('near_tie' if fusion<=1.03 else 'improvement'))
        row['serial_contract']='G distinct group views; same stream; no per-group synchronize; retain outputs; no concatenation'
        row['serial_algorithm']=a.algorithm
    sk=plan['gW_split'] or a.split_k or kernel.workspace_split(g,f,c,o,r,s,p,q,torch.cuda.get_device_properties(args[5].device).multi_processor_count,int(a.workspace_mb*1024**2))
    row.update(split_k=sk,scratch_bytes=max(plan['scratch_bytes'],0 if plan['gW_split'] or sk==1 else 4*g*sk*o*c*r*s))
    for name,active,win,implicit in [('ggO',plan['ggO_nt'],kernel._packed_conv,kernel._ggo),('gI',plan['gI_nt'],kernel._packed_conv,kernel._gi),('gW',plan['gW_split'],kernel._packed_gw,kernel._gw)]:
        row[name+'_algorithm']=('winograd_v'+str(plan.get('version',5))) if active else 'implicit'
        # _packed_conv is shared by ggO/gI; capture each stage configuration immediately.
        row.setdefault(name+'_config',str(getattr(implicit,'best_config','unavailable')) if not active else 'not captured: enable stages for per-output configuration')
    row['winograd_plan']=plan
    row['experimental']=a.algorithm.startswith('winograd')
    row['joint_ggO_gW']=bool(plan.get('joint_nt'))
    for label in ('aten_prepacked','aten_e2e'):
        if label+'_event_median' not in row:continue
        row[label+'_speedup']=row[label+'_event_median']/row['triton_event_median']
    torch_ms=row.get('best_aten_baseline_ms',row['aten_prepacked_event_median'])
    speed=row.get('best_aten_speedup',row['aten_prepacked_speedup'])
    row['policy_reference']='best cached serial/grouped ATen' if cached else 'same-run grouped ATen'
    noisy=max(row['triton_event_cv_pct'],row['aten_prepacked_event_cv_pct'],row.get('serial_aten_baseline_cv_pct',0))>a.max_cv
    if noisy:row['policy']='unstable'
    elif g==1 or torch_ms<a.small_ms:
        bound=max(torch_ms*(1+a.small_slowdown_pct/100),torch_ms+a.small_extra_us/1000)
        row['policy']='allowed_small' if row['triton_event_median']<=bound else 'small_regression'
    elif .97<=speed<=1.03:row['policy']='inconclusive_near_tie'
    else:row['policy']='pass_candidate' if speed>1.03 else 'large_regression'
    if a.compare_graph:
        row['graph_diagnostic']={}
        for name in ('triton','aten_prepacked','aten_e2e'):
            if name not in funcs:continue
            print('  graph diagnostic',name,flush=True)
            try:row['graph_diagnostic'][name]=graph_probe(funcs[name],a)
            except Exception as e:row['graph_diagnostic'][name]=dict(status='error',error=repr(e))
    if a.profile_kernels:
        row['cuda_profile']={}
        for name in ('triton','aten_prepacked','stage_ggO','stage_gI','stage_gW'):
            if name not in funcs:continue
            print('  CUDA trace',name,flush=True)
            try:row['cuda_profile'][name]=profile_callable(funcs[name],a.profile_iters)
            except Exception as e:row['cuda_profile'][name]=dict(status='error',error=repr(e))
    return dict(row,status='ok')


def summary(row):
    title=f"{row['case']} | G={row['G']} batch={row['F']} | {row['status']}"
    if row['status']!='ok':
        return title+' | '+row.get('error','')
    lines=[title+f" | {row['policy']}"]
    lines.append('  policy reference: '+row.get('policy_reference','grouped ATen'))
    if row.get('aten_baseline_reused'):
        lines.append(f"  cached ATen baseline (different run): best(serial,grouped)={row['best_aten_baseline_ms']:.6f} ms speedup={row['best_aten_speedup']:.3f}x; near ties need same-run confirmation")
        lines.append('  task_peak(MiB): '+ ' '.join(n+'='+format(row[n+'_task_peak_bytes']/1048576,'.2f') for n in ('triton','aten_prepacked','aten_e2e'))+' (inputs + layout copies + peak extra allocations)')
    if 'schedule' in row.get('winograd_plan',{}):lines.append('  schedule: '+row['winograd_plan']['schedule']+' (provisional shape/workspace policy)')
    lines.append('  algorithms: '+' '.join(n+'='+row.get(n+'_algorithm','implicit') for n in ('ggO','gI','gW')))
    if row.get('gW_validation')=='fp64_resolved':
        lines.append(f"  validation: gW FP64-resolved; ATen mismatches={row['gW_aten_mismatches']}, checked={row['gW_fp64_checked']}, Triton max_abs={row['gW_fp64_max_abs']:.3e}, ATen max_abs={row['gW_aten_fp64_max_abs']:.3e} (checked positions only)")
    lines.append(f"  time(ms): Triton={row['triton_event_median']:.6f} ATen={row['aten_prepacked_event_median']:.6f} ATen+layout={row['aten_e2e_event_median']:.6f}")
    lines.append(f"  speedup: ATen={row['aten_prepacked_speedup']:.3f}x E2E={row['aten_e2e_speedup']:.3f}x | CV: Triton={row['triton_event_cv_pct']:.2f}% ATen={row['aten_prepacked_event_cv_pct']:.2f}%")
    if 'triton_implicit_event_median' in row:
        lines.append(f"  previous implicit(ms)={row['triton_implicit_event_median']:.6f} | speedup vs implicit={row['triton_implicit_event_median']/row['triton_event_median']:.3f}x")
    if 'triton_v8_event_median' in row:
        lines.append(f"  v8(ms)={row['triton_v8_event_median']:.6f} speedup_vs_v8={row['triton_v8_event_median']/row['triton_event_median']:.3f}x (same workspace budget)")
    if 'triton_v7_event_median' in row:
        lines.append(f"  v7(ms)={row['triton_v7_event_median']:.6f} speedup_vs_v7={row['triton_v7_event_median']/row['triton_event_median']:.3f}x")
    if 'triton_v6_event_median' in row:
        lines.append(f"  v6(ms)={row['triton_v6_event_median']:.6f} speedup_vs_v6={row['triton_v6_event_median']/row['triton_event_median']:.3f}x")
    if 'triton_v5_event_median' in row:
        lines.append(f"  v5(ms)={row['triton_v5_event_median']:.6f} speedup_vs_v5={row['triton_v5_event_median']/row['triton_event_median']:.3f}x")
    for alg in ('winograd_joint','winograd_separate'):
        if alg+'_event_median' in row:
            lines.append(f"  {alg}(ms)={row[alg+'_event_median']:.6f} CV={row[alg+'_event_cv_pct']:.2f}%")
    if 'joint_ggO_config' in row:lines.append('  joint ggO config: '+row['joint_ggO_config'])
    if 'serial_triton_event_median' in row:
        lines.append(f"  serial G calls(ms): ATen={row['serial_aten_event_median']:.6f} Triton={row['serial_triton_event_median']:.6f}")
        lines.append(f"  scaling: serial_ATen/fused_Triton={row['serial_aten_over_fused_triton']:.3f}x serial_Triton/fused_Triton={row['serial_triton_over_fused_triton']:.3f}x serial_ATen/grouped_ATen={row['serial_aten_over_grouped_aten']:.3f}x")
        lines.append(f"  throughput={row['group_images_per_second']:.1f} group-images/s | fusion_efficiency={row['fusion_efficiency_pct']:.1f}% | stable={row['scaling_stable']} | fusion={row.get('fusion_policy','unclassified')}")
        lines.append(f"  serial CV: ATen={row['serial_aten_event_cv_pct']:.2f}% Triton={row['serial_triton_event_cv_pct']:.2f}%")
    if row.get('joint_ggO_gW'):lines.append('  ggO+gW share transformed ggI in full API; isolated stage times do not include this reuse.')
    if 'stage_ggO_event_median' in row:
        lines.append('  stages(ms): '+' '.join(n+'='+format(row['stage_'+n+'_event_median'],'.6f') for n in ('ggO','gI','gW')))
    lines.append('  error(rel_L2): '+' '.join(n+'='+format(row[n+'_rel_l2'],'.3e') for n in ('ggO','gI','gW')))
    lines.append('  peak_extra(MiB): '+' '.join(n+'='+format(row[n+'_peak_extra_bytes']/1048576,'.2f') for n in ('triton','aten_prepacked','aten_e2e'))+f" | split_k={row['split_k']}")
    for name,v in row.get('graph_diagnostic',{}).items():
        if v['status']=='ok':
            ms=v['event_ms']['median'];eager=row[name+'_event_median']
            lines.append(f"  GRAPH {name}: replay_ms={ms:.6f} eager/replay={eager/ms:.3f} CV={v['event_ms']['cv_pct']:.2f}% (diagnostic only)")
        else:lines.append('  GRAPH '+name+': '+str(v))
    for name,v in row.get('cuda_profile',{}).items():
        if v['status']!='ok':lines.append('  PROFILE '+name+': '+str(v));continue
        lines.append(f"  PROFILE {name}: activity_ms/API={v['activity_ms_per_api']:.6f} uncovered_span={v['uncovered_span_pct']:.2f}% (instrumented; not SM utilization)")
        records=v['families'] if name!='aten_prepacked' else v['kernels'][:12]
        for r in records:
            lines.append(f"    {r['name']} calls/API={r['calls_per_api']:.1f} ms/API={r['ms_per_api']:.6f} mean_us={r['mean_us']:.3f} share={r['activity_share_pct']:.1f}%")
    return '\n'.join(lines)


@torch.no_grad()
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('mode',choices=['correctness','bench','list'])
    ap.add_argument('--models',nargs='+',choices=['conv3','resnet18'],default=['conv3','resnet18'])
    ap.add_argument('--datasets',nargs='+',choices=['cifar10','imagenet'],default=['cifar10','imagenet'])
    ap.add_argument('--imagenet-sizes',nargs='+',type=int,default=[128,224])
    ap.add_argument('--stem',choices=['auto','small','standard','both'],default='auto')
    ap.add_argument('--width',type=int,default=128)
    ap.add_argument('--groups',nargs='+',type=int,default=[1,2,4,8,16,32])
    ap.add_argument('--batch',nargs='+',type=int,default=[1,10,32,100,256,1000])
    ap.add_argument('--filter',default='',help='Substring of case name')
    ap.add_argument('--dtype',choices=['fp32','fp16','bf16'],default='fp32')
    ap.add_argument('--profile-kernels',action='store_true',help='After normal timing, summarize CUDA traces in the same TXT; no hardware counters')
    ap.add_argument('--profile-iters',type=int,default=3)
    ap.add_argument('--compare-graph',action='store_true',help='Diagnostic CUDA graph replay for both Triton and ATen; eager measurements remain primary')
    ap.add_argument('--compare-v5',action='store_true',help='Time the unchanged v5 packed path on identical inputs')
    ap.add_argument('--compare-implicit',action='store_true',help='Also time the previous implicit implementation on identical inputs')
    ap.add_argument('--compare-schedules',action='store_true',help='Compare joint/separate v8 on identical inputs')
    ap.add_argument('--focus-large',action='store_true',help='Eight CIFAR10 cases: Conv3 conv2 and ResNet18 stage1; B=100/1000, G=2/8')
    ap.add_argument('--aten-baseline',help='Reuse benchmark_aten.py TXT; no ATen performance remeasurement')
    ap.add_argument('--compare-v8',action='store_true',help='Also time v8 with the SAME workspace budget')
    ap.add_argument('--compare-v7',action='store_true',help='Time unchanged v7 on the same inputs')
    ap.add_argument('--scaling',action='store_true',help='Measure G independent calls without per-group synchronization')
    ap.add_argument('--compare-v6',action='store_true',help='Time unchanged v6 on the same inputs')
    ap.add_argument('--algorithm',choices=['auto','implicit','winograd','winograd_v5','winograd_v6','winograd_v7','winograd_v8','winograd_large','winograd_joint','winograd_separate'],default='auto',help='winograd_large tests the v9 candidate; auto/implicit retain the original generic path')
    ap.add_argument('--precision',choices=['ieee','tf32','tf32x3'],default='ieee')
    ap.add_argument('--rounds',type=int,default=5);ap.add_argument('--warmup',type=int,default=20)
    ap.add_argument('--warmup-ms',type=float,default=200);ap.add_argument('--target-ms',type=float,default=100)
    ap.add_argument('--iters',type=int,default=100,help='Maximum calls per round; adaptive minimum 2')
    ap.add_argument('--workspace-mb',type=float,default=128)
    ap.add_argument('--split-k',type=int,choices=[1,2,4,8,16])
    ap.add_argument('--memory-fraction',type=float,default=.65)
    ap.add_argument('--small-ms',type=float,default=.05,help='Provisional fast-case cutoff; 0.05ms=50us')
    ap.add_argument('--max-cv',type=float,default=5)
    ap.add_argument('--small-slowdown-pct',type=float,default=20)
    ap.add_argument('--small-extra-us',type=float,default=10)
    ap.add_argument('--stages',action=argparse.BooleanOptionalAction,default=False)
    ap.add_argument('--resume',action='store_true');ap.add_argument('--output',default=None,help='Optional single TXT report; otherwise console only')
    a=ap.parse_args()
    if a.focus_large:
        a.groups=[2,8];a.batch=[100,1000];a.datasets=['cifar10'];a.models=['conv3','resnet18'];a.width=128;a.stem='small'
        if a.algorithm=='auto':a.algorithm='winograd_large'
    if a.aten_baseline and (a.scaling or a.compare_graph):ap.error('--aten-baseline cannot combine with --scaling/--compare-graph')
    if min(a.groups+a.batch+a.imagenet_sizes+[a.width,a.warmup,a.rounds,a.iters,a.profile_iters])<1 or a.rounds<2 or a.iters<2:ap.error('Positive dimensions/warmup; rounds and iters >=2')
    if not 0<a.memory_fraction<=1 or min(a.workspace_mb,a.warmup_ms,a.target_ms,a.small_ms,a.max_cv,a.small_slowdown_pct,a.small_extra_us)<0:ap.error('Invalid budget/timing parameters')
    suite=[c for c in cases(a.models,a.datasets,a.imagenet_sizes,a.stem,a.width) if a.filter in c['case']]
    if a.focus_large:
        suite=[c for c in suite if (c['model']=='conv3' and c['name']=='conv2') or (c['model']=='resnet18' and (c['C'],c['O'],c['H'],c['R'],c['stride'])==(64,64,32,3,1))]
    if not suite:ap.error('No matching cases')
    if a.mode=='list':
        print(json.dumps(suite,indent=2));print('Total configurations:',len(suite)*len(a.groups)*len(a.batch));return
    if not torch.cuda.is_available():raise SystemExit('CUDA GPU required')
    torch.manual_seed(123);torch.backends.cudnn.benchmark=True
    torch.backends.cudnn.allow_tf32=a.precision=='tf32';torch.backends.cuda.matmul.allow_tf32=a.precision=='tf32'
    dtype={'fp32':torch.float32,'fp16':torch.float16,'bf16':torch.bfloat16}[a.dtype]
    if a.mode=='correctness':
        (correctness_large if a.focus_large else correctness)(dtype,a.precision);return
    hashes={n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in ('benchmark.py','conv_double_bwd.py')}
    meta=dict(benchmark_revision="v9-large-1",source_sha256=hashes,torch=torch.__version__,triton=triton.__version__,cuda=torch.version.cuda,cudnn=torch.backends.cudnn.version(),gpu=torch.cuda.get_device_name(),args=vars(a))
    if a.aten_baseline:
        meta['baseline_sha256']=hashlib.sha256(Path(a.aten_baseline).read_bytes()).hexdigest()
        load_baseline(a.aten_baseline,meta,a)
    print('ENV '+json.dumps(meta,ensure_ascii=False),flush=True)
    file=Path(a.output) if a.output else None
    if file and file.suffix.lower()!='.txt':ap.error('--output must end with .txt')
    if a.resume and file is None:ap.error('--resume requires --output')
    done=set()
    if file and a.resume and file.exists():
        old=None
        with file.open(encoding='utf-8') as fh:
            for line in fh:
                if line.startswith('ENV '):old=json.loads(line[4:])
                elif line.startswith('RESULT '):
                    try:row=json.loads(line[7:])
                    except json.JSONDecodeError:continue  # interrupted final line
                    if row['status'] in ('ok','skip_index_limit','skip_memory_estimate','skip_missing_baseline'):
                        done.add((row['case'],row['G'],row['F']))
        if old is None:raise SystemExit('Missing report environment header')
        old['args']['resume']=True
        if old!=meta:raise SystemExit('Resume metadata mismatch; use a new output name')
    elif file and file.exists():raise SystemExit('Output exists; use --resume or another filename')
    fh=file.open('a',encoding='utf-8') if file else None
    try:
        if fh:
            if file.stat().st_size==0:fh.write('ENV '+json.dumps(meta,ensure_ascii=False)+'\n')
            else:fh.write('\n')
            fh.flush()
        totals={}
        for case in suite:
            for g in a.groups:
                for f in a.batch:
                    if (case['case'],g,f) in done:continue
                    print('Testing',case['case'],'G',g,'batch',f,flush=True)
                    fatal=False
                    try:row=run(case,g,f,a)
                    except torch.cuda.OutOfMemoryError as e:row=dict(case,G=g,F=f,status='oom',error=str(e))
                    except Exception as e:
                        row=dict(case,G=g,F=f,status='error',error=repr(e));fatal=True
                        if isinstance(e,ValidationError):row['validation']=e.details
                    msg=summary(row);print(msg,flush=True)
                    totals[row.get('policy',row['status'])]=totals.get(row.get('policy',row['status']),0)+1
                    if fh:
                        fh.write(msg+'\nRESULT '+json.dumps(row,ensure_ascii=False)+'\n');fh.flush()
                    gc.collect();torch.cuda.empty_cache()
                    if fatal:raise SystemExit('Stopped after recorded error')
        msg='SUMMARY '+json.dumps(totals,ensure_ascii=False)
        print(msg,flush=True)
        if fh:fh.write(msg+'\n');fh.flush()
    finally:
        if fh:fh.close()

if __name__=='__main__':main()
