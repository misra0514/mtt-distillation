"""Stateless group-first convolution double backward v9; target: NVIDIA sm80+.
No autograd, ATen convolution calls, cached tensors or global scratch buffers.
"""
import torch
import triton
import triton.language as tl

_SHAPE_KEY=['G','F','C','H','W','O','R','S','P','Q','SH','SW','PH','PW','DH','DW','PREC']

def _configs():
    return [triton.Config(dict(BM=m,BN=n,BK=k),num_warps=warps,num_stages=stages)
            for m,n,k,warps,stages in [(16,64,32,4,2),(32,64,32,4,3),
                (32,128,32,4,3),(64,64,32,4,3),(32,64,64,4,3)]]

def _spatial_configs():
    # Keep every v1 candidate. Add fixed-(r,s) iterators with spatial-contiguous loads.
    return [triton.Config(dict(**cfg.kwargs, RS_LOOP=rs, BATCH_FOLD=fold),
                          num_warps=cfg.num_warps,num_stages=cfg.num_stages)
            for fold in (False,True) for rs in (False,True) for cfg in (_configs()+[
                triton.Config(dict(BM=16,BN=32,BK=32),num_warps=2,num_stages=2),
                triton.Config(dict(BM=32,BN=32,BK=32),num_warps=4,num_stages=2),
                triton.Config(dict(BM=32,BN=64,BK=16),num_warps=4,num_stages=2)])]

def _prune_spatial(configs,named_args,**kwargs):
    a=dict(named_args,**kwargs)
    use_rs=1<a['R']*a['S']<=9 and min(a['C'],a['O'])>=16
    use_fold=a['F']>1 and min(a['H']*a['W'],a['P']*a['Q'])<=64
    return [cfg for cfg in configs if (a['PREC']=='ieee' or (cfg.kwargs['BN']!=32 and cfg.kwargs['BK']!=16)) and (use_rs or not cfg.kwargs['RS_LOOP']) and (use_fold or not cfg.kwargs['BATCH_FOLD'])]

@triton.autotune(configs=_spatial_configs(),key=_SHAPE_KEY+['HI','HW','HB'],prune_configs_by={'early_config_prune':_prune_spatial})
@triton.jit
def _ggo(X,Wt,AI,AW,AB,Y,G:tl.constexpr,F:tl.constexpr,C:tl.constexpr,
         H:tl.constexpr,W:tl.constexpr,O:tl.constexpr,R:tl.constexpr,S:tl.constexpr,
         P:tl.constexpr,Q:tl.constexpr,SH:tl.constexpr,SW:tl.constexpr,
         PH:tl.constexpr,PW:tl.constexpr,DH:tl.constexpr,DW:tl.constexpr,
         PREC:tl.constexpr,HI:tl.constexpr,HW:tl.constexpr,HB:tl.constexpr,
         BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr,RS_LOOP:tl.constexpr,BATCH_FOLD:tl.constexpr):
    pid=tl.program_id(0); gf=tl.program_id(1)
    g=gf if BATCH_FOLD else gf//F
    nn=tl.cdiv(F*P*Q if BATCH_FOLD else P*Q,BN); nm=tl.cdiv(O,BM)
    first=pid//(4*nn)*4; count=tl.minimum(nm-first,4)
    mi=first+(pid%(4*nn))%count; ni=(pid%(4*nn))//count
    oc=mi*BM+tl.arange(0,BM); n=ni*BN+tl.arange(0,BN)
    spatial=n%(P*Q) if BATCH_FOLD else n
    batch=n//(P*Q) if BATCH_FOLD else tl.full((BN,),gf%F,tl.int32)
    nlimit:tl.constexpr=F*P*Q if BATCH_FOLD else P*Q
    kk=tl.arange(0,BK)
    acc1=tl.zeros((BM,BN),tl.float32); acc2=tl.zeros((BM,BN),tl.float32)
    if HI or HW:
        if RS_LOOP:
            # Keep filter loops rolled to bound compile time/register live ranges.
            # Address arithmetic for spatial coordinates is invariant across channel blocks.
            for rr in range(R):
                for ss in range(S):
                    ih=spatial//Q*SH-PH+rr*DH; iw=spatial%Q*SW-PW+ss*DW
                    valid=(n<nlimit)&(ih>=0)&(ih<H)&(iw>=0)&(iw<W)
                    for cb in range(tl.cdiv(C,BK)):
                        ci=cb*BK+kk
                        xo=(g*F+batch[None,:])*C*H*W+ci[:,None]*H*W+ih[None,:]*W+iw[None,:]
                        wo=g*O*C*R*S+oc[:,None]*C*R*S+ci[None,:]*R*S+rr*S+ss
                        xm=(ci[:,None]<C)&valid[None,:]
                        wm=(oc[:,None]<O)&(ci[None,:]<C)
                        if HI:
                            a=tl.load(Wt+wo,wm,0); b=tl.load(AI+xo,xm,0)
                            acc1=tl.dot(a,b,acc1,input_precision=PREC)
                        if HW:
                            a=tl.load(AW+wo,wm,0); b=tl.load(X+xo,xm,0)
                            acc2=tl.dot(a,b,acc2,input_precision=PREC)
        else:
            for kb in range(tl.cdiv(C*R*S,BK)):
                k=kb*BK+kk
                ih=spatial[None,:]//Q*SH-PH+(k[:,None]//S%R)*DH
                iw=spatial[None,:]%Q*SW-PW+(k[:,None]%S)*DW
                xo=(g*F+batch[None,:])*C*H*W+(k[:,None]//(R*S))*H*W+ih*W+iw
                wo=g*O*C*R*S+oc[:,None]*C*R*S+k[None,:]
                xm=(k[:,None]<C*R*S)&(n[None,:]<nlimit)&(ih>=0)&(ih<H)&(iw>=0)&(iw<W)
                wm=(oc[:,None]<O)&(k[None,:]<C*R*S)
                if HI:
                    a=tl.load(Wt+wo,wm,0); b=tl.load(AI+xo,xm,0)
                    acc1=tl.dot(a,b,acc1,input_precision=PREC)
                if HW:
                    a=tl.load(AW+wo,wm,0); b=tl.load(X+xo,xm,0)
                    acc2=tl.dot(a,b,acc2,input_precision=PREC)
    # Match the intermediate dtype rounding of the two ATen conv outputs.
    if HI and HW:
        val=(acc1.to(Y.dtype.element_ty).to(tl.float32)+acc2.to(Y.dtype.element_ty).to(tl.float32)).to(Y.dtype.element_ty).to(tl.float32)
    elif HI:
        val=acc1.to(Y.dtype.element_ty).to(tl.float32)
    else:
        val=acc2.to(Y.dtype.element_ty).to(tl.float32)
    if HB:
        val+=tl.load(AB+g*O+oc,oc<O,0)[:,None]
    tl.store(Y+((g*F+batch[None,:])*O+oc[:,None])*P*Q+spatial[None,:],val,(oc[:,None]<O)&(n[None,:]<nlimit))

@triton.autotune(configs=_spatial_configs(),key=_SHAPE_KEY,prune_configs_by={'early_config_prune':_prune_spatial})
@triton.jit
def _gi(D,AW,Y,G:tl.constexpr,F:tl.constexpr,C:tl.constexpr,
        H:tl.constexpr,W:tl.constexpr,O:tl.constexpr,R:tl.constexpr,S:tl.constexpr,
        P:tl.constexpr,Q:tl.constexpr,SH:tl.constexpr,SW:tl.constexpr,
        PH:tl.constexpr,PW:tl.constexpr,DH:tl.constexpr,DW:tl.constexpr,
        PREC:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr,RS_LOOP:tl.constexpr,BATCH_FOLD:tl.constexpr):
    pid=tl.program_id(0); gf=tl.program_id(1)
    g=gf if BATCH_FOLD else gf//F
    nn=tl.cdiv(F*H*W if BATCH_FOLD else H*W,BN)
    ci=pid//nn*BM+tl.arange(0,BM); n=pid%nn*BN+tl.arange(0,BN)
    spatial=n%(H*W) if BATCH_FOLD else n
    batch=n//(H*W) if BATCH_FOLD else tl.full((BN,),gf%F,tl.int32)
    nlimit:tl.constexpr=F*H*W if BATCH_FOLD else H*W
    kk=tl.arange(0,BK); acc=tl.zeros((BM,BN),tl.float32)
    # Gather dgrad: no expanded dY and no col2im/atomic scatter.
    if RS_LOOP:
        for rr in range(R):
            for ss in range(S):
                hp=spatial//W+PH-rr*DH; wp=spatial%W+PW-ss*DW
                py=hp//SH; qx=wp//SW
                valid=(n<nlimit)&(hp%SH==0)&(wp%SW==0)&(py>=0)&(py<P)&(qx>=0)&(qx<Q)
                for cb in range(tl.cdiv(O,BK)):
                    oc=cb*BK+kk
                    a=tl.load(AW+g*O*C*R*S+oc[None,:]*C*R*S+ci[:,None]*R*S+rr*S+ss,
                              (ci[:,None]<C)&(oc[None,:]<O),0)
                    b=tl.load(D+(g*F+batch[None,:])*O*P*Q+oc[:,None]*P*Q+py[None,:]*Q+qx[None,:],
                              (oc[:,None]<O)&valid[None,:],0)
                    acc=tl.dot(a,b,acc,input_precision=PREC)
    else:
        for kb in range(tl.cdiv(O*R*S,BK)):
            k=kb*BK+kk; oc=k//(R*S); r=k//S%R; s=k%S
            hp=spatial[None,:]//W+PH-r[:,None]*DH
            wp=spatial[None,:]%W+PW-s[:,None]*DW
            py=hp//SH; qx=wp//SW
            a=tl.load(AW+g*O*C*R*S+oc[None,:]*C*R*S+ci[:,None]*R*S+r[None,:]*S+s[None,:],
                      (ci[:,None]<C)&(oc[None,:]<O),0)
            b=tl.load(D+(g*F+batch[None,:])*O*P*Q+oc[:,None]*P*Q+py*Q+qx,
                      (oc[:,None]<O)&(n[None,:]<nlimit)&(hp%SH==0)&(wp%SW==0)&
                      (py>=0)&(py<P)&(qx>=0)&(qx<Q),0)
            acc=tl.dot(a,b,acc,input_precision=PREC)
    tl.store(Y+((g*F+batch[None,:])*C+ci[:,None])*H*W+spatial[None,:],acc,(ci[:,None]<C)&(n[None,:]<nlimit))

def _wgrad_configs():
    flat=[triton.Config(dict(**c.kwargs,FIXED_RS=False),num_warps=c.num_warps,num_stages=c.num_stages) for c in _configs()]
    fixed=[triton.Config(dict(BM=m,BN=n,BK=k,FIXED_RS=True),num_warps=w,num_stages=st)
           for m,n,k,w,st in [(32,32,32,4,2),(32,64,32,4,3),(64,32,32,4,3),(32,32,64,4,3),(16,32,64,4,2)]]
    return flat+fixed

@triton.autotune(configs=_wgrad_configs(),key=_SHAPE_KEY+['SPLIT'])
@triton.jit
def _gw(AI,D,Y,G:tl.constexpr,F:tl.constexpr,C:tl.constexpr,
        H:tl.constexpr,W:tl.constexpr,O:tl.constexpr,R:tl.constexpr,S:tl.constexpr,
        P:tl.constexpr,Q:tl.constexpr,SH:tl.constexpr,SW:tl.constexpr,
        PH:tl.constexpr,PW:tl.constexpr,DH:tl.constexpr,DW:tl.constexpr,
        PREC:tl.constexpr,SPLIT:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr,FIXED_RS:tl.constexpr):
    pid=tl.program_id(0); gs=tl.program_id(1); g=gs//SPLIT; part=gs%SPLIT
    if FIXED_RS:
        # One filter position per CTA. Both operands load contiguous spatial K.
        # Compute [C,O] and transpose on store, avoiding the strided CRS gather.
        nn=tl.cdiv(O,BN); tiles=tl.cdiv(C,BM)*nn
        rs=pid//tiles; tile=pid%tiles
        ci=tile//nn*BM+tl.arange(0,BM)
        oc=tile%nn*BN+tl.arange(0,BN)
        rr=rs//S; ss=rs%S
    else:
        nn=tl.cdiv(C*R*S,BN)
        oc=pid//nn*BM+tl.arange(0,BM); crs=pid%nn*BN+tl.arange(0,BN)
        ci=crs//(R*S); rr=crs//S%R; ss=crs%S
    kk=tl.arange(0,BK)
    acc=tl.zeros((BM,BN),tl.float32); correction=tl.zeros((BM,BN),tl.float32)
    # Long reductions use 512-term partial sums plus compensated outer summation.
    # No extra global workspace, and the original validation tolerances stay fixed.
    CHUNKED:tl.constexpr=F*P*Q>=SPLIT*8192
    INNER:tl.constexpr=512//BK if CHUNKED else 1
    for chunk in range(tl.cdiv(F*P*Q,SPLIT*BK*INNER)):
        partial=tl.zeros((BM,BN),tl.float32)
        for block in range(INNER):
            k=((chunk*INNER+block)*SPLIT+part)*BK+kk
            f=k//(P*Q); py=k//Q%P; qx=k%Q
            if FIXED_RS:
                ih=py*SH-PH+rr*DH; iw=qx*SW-PW+ss*DW
                a=tl.load(AI+(g*F+f[None,:])*C*H*W+ci[:,None]*H*W+ih[None,:]*W+iw[None,:],
                          (ci[:,None]<C)&(k[None,:]<F*P*Q)&(ih[None,:]>=0)&(ih[None,:]<H)&(iw[None,:]>=0)&(iw[None,:]<W),0)
                b=tl.load(D+(g*F+f[:,None])*O*P*Q+oc[None,:]*P*Q+py[:,None]*Q+qx[:,None],
                          (oc[None,:]<O)&(k[:,None]<F*P*Q),0)
            else:
                ih=py[:,None]*SH-PH+rr[None,:]*DH
                iw=qx[:,None]*SW-PW+ss[None,:]*DW
                a=tl.load(D+g*F*O*P*Q+f[None,:]*O*P*Q+oc[:,None]*P*Q+py[None,:]*Q+qx[None,:],
                          (oc[:,None]<O)&(k[None,:]<F*P*Q),0)
                b=tl.load(AI+g*F*C*H*W+f[:,None]*C*H*W+ci[None,:]*H*W+ih*W+iw,
                          (k[:,None]<F*P*Q)&(crs[None,:]<C*R*S)&(ih>=0)&(ih<H)&(iw>=0)&(iw<W),0)
            if CHUNKED:
                partial=tl.dot(a,b,partial,input_precision=PREC)
            else:
                acc=tl.dot(a,b,acc,input_precision=PREC)
        if CHUNKED:
            delta=partial-correction
            updated=acc+delta
            correction=(updated-acc)-delta
            acc=updated
    if FIXED_RS:
        offsets=gs*O*C*R*S+oc[None,:]*C*R*S+ci[:,None]*R*S+rs
        tl.store(Y+offsets,acc,(ci[:,None]<C)&(oc[None,:]<O))
    else:
        tl.store(Y+gs*O*C*R*S+oc[:,None]*C*R*S+crs[None,:],acc,
                 (oc[:,None]<O)&(crs[None,:]<C*R*S))

@triton.jit
def _reduce(T,Y,N:tl.constexpr,PER:tl.constexpr,SPLIT:tl.constexpr,BLOCK:tl.constexpr):
    i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK)
    g=i//PER; j=i%PER
    acc=tl.full((BLOCK,),0,tl.float32)
    for s in tl.static_range(SPLIT):
        acc+=tl.load(T+(g*SPLIT+s)*PER+j,i<N,0)
    tl.store(Y+i,acc,i<N)

# Winograd F(2x2,3x3): BT rows (1,0,-1,0),(0,1,1,0),
# (0,-1,1,0),(0,-1,0,1); AT rows (1,1,1,0),(0,1,-1,1).
# Transform equations: https://github.com/andravin/wincnn (F(2,3)).
@triton.jit
def _win_input(X,g,ci,t,tr,tc,F:tl.constexpr,C:tl.constexpr,H:tl.constexpr,W:tl.constexpr,
               TH:tl.constexpr,TW:tl.constexpr,PH:tl.constexpr,PW:tl.constexpr):
    f=t//(TH*TW); y=t//TW%TH*2-PH; x=t%TW*2-PW
    r0=tl.where(tr==0,0,1);r1=tl.where(tr==3,3,2)
    c0=tl.where(tc==0,0,1);c1=tl.where(tc==3,3,2)
    sr0=tl.where(tr>=2,-1.,1.);sr1=tl.where(tr==0,-1.,1.)
    sc0=tl.where(tc>=2,-1.,1.);sc1=tl.where(tc==0,-1.,1.)
    base=((g*F+f)*C+ci)*H*W
    valid=(f<F)&(ci<C)
    a=tl.load(X+base+(y+r0)*W+x+c0,valid&(y+r0>=0)&(y+r0<H)&(x+c0>=0)&(x+c0<W),0)
    b=tl.load(X+base+(y+r0)*W+x+c1,valid&(y+r0>=0)&(y+r0<H)&(x+c1>=0)&(x+c1<W),0)
    c=tl.load(X+base+(y+r1)*W+x+c0,valid&(y+r1>=0)&(y+r1<H)&(x+c0>=0)&(x+c0<W),0)
    d=tl.load(X+base+(y+r1)*W+x+c1,valid&(y+r1>=0)&(y+r1<H)&(x+c1>=0)&(x+c1<W),0)
    return sr0*(sc0*a+sc1*b)+sr1*(sc0*c+sc1*d)

@triton.jit
def _win_g(tr,k:tl.constexpr):
    return tl.where(tr==0,1. if k==0 else 0.,tl.where(tr==3,1. if k==2 else 0.,tl.where((tr==2)&(k==1),-.5,.5)))

@triton.jit
def _win_weight(Wt,g,oc,ci,tr,tc,C:tl.constexpr,O:tl.constexpr,FLIP:tl.constexpr):
    v=tl.full((oc.shape[0],ci.shape[1]),0,tl.float32)
    for r in tl.static_range(3):
        for s in tl.static_range(3):
            coef=_win_g(tr,r)*_win_g(tc,s)
            if FLIP:off=g*O*C*9+ci*O*9+oc*9+(2-r)*3+2-s
            else:off=g*O*C*9+oc*C*9+ci*9+r*3+s
            w=tl.load(Wt+off,(oc<O)&(ci<C),0)
            v+=coef*w
    return v

@triton.jit
def _win_weight_pack(Wt,U,G:tl.constexpr,C:tl.constexpr,O:tl.constexpr,FLIP:tl.constexpr):
    pid=tl.program_id(0);g=tl.program_id(1);z=tl.program_id(2)
    oc=pid//tl.cdiv(C,32)*16+tl.arange(0,16)
    ci=pid%tl.cdiv(C,32)*32+tl.arange(0,32)
    v=_win_weight(Wt,g,oc[:,None],ci[None,:],z//4,z%4,C,O,FLIP)
    tl.store(U+((z*G+g)*O+oc[:,None])*C+ci[None,:],v,(oc[:,None]<O)&(ci[None,:]<C))

@triton.jit
def _win_out(M,Bias,Y,start,G:tl.constexpr,F:tl.constexpr,O:tl.constexpr,P:tl.constexpr,Q:tl.constexpr,
             NT:tl.constexpr,HB:tl.constexpr,BLOCK:tl.constexpr):
    i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK)
    n=i%NT;oc=i//NT%O;g=i//(NT*O);t=start+n
    f=t//(((P+1)//2)*((Q+1)//2));y=t//((Q+1)//2)%((P+1)//2)*2;x=t%((Q+1)//2)*2
    valid=(i<G*O*NT)&(f<F)
    base=(g*O+oc)*NT+n;step=G*O*NT
    m00=tl.load(M+0*step+base,valid,0)
    m01=tl.load(M+1*step+base,valid,0)
    m02=tl.load(M+2*step+base,valid,0)
    m03=tl.load(M+3*step+base,valid,0)
    m10=tl.load(M+4*step+base,valid,0)
    m11=tl.load(M+5*step+base,valid,0)
    m12=tl.load(M+6*step+base,valid,0)
    m13=tl.load(M+7*step+base,valid,0)
    m20=tl.load(M+8*step+base,valid,0)
    m21=tl.load(M+9*step+base,valid,0)
    m22=tl.load(M+10*step+base,valid,0)
    m23=tl.load(M+11*step+base,valid,0)
    m30=tl.load(M+12*step+base,valid,0)
    m31=tl.load(M+13*step+base,valid,0)
    m32=tl.load(M+14*step+base,valid,0)
    m33=tl.load(M+15*step+base,valid,0)
    v00=m00+m10+m20
    v10=m10-m20+m30
    v01=m01+m11+m21
    v11=m11-m21+m31
    v02=m02+m12+m22
    v12=m12-m22+m32
    v03=m03+m13+m23
    v13=m13-m23+m33
    bias=tl.load(Bias+g*O+oc,valid,0) if HB else tl.full((BLOCK,),0,tl.float32)
    tl.store(Y+((g*F+f)*O+oc)*P*Q+(y+0)*Q+x+0,v00+v01+v02+bias,valid&(y+0<P)&(x+0<Q))
    tl.store(Y+((g*F+f)*O+oc)*P*Q+(y+0)*Q+x+1,v01-v02+v03+bias,valid&(y+0<P)&(x+1<Q))
    tl.store(Y+((g*F+f)*O+oc)*P*Q+(y+1)*Q+x+0,v10+v11+v12+bias,valid&(y+1<P)&(x+0<Q))
    tl.store(Y+((g*F+f)*O+oc)*P*Q+(y+1)*Q+x+1,v11-v12+v13+bias,valid&(y+1<P)&(x+1<Q))

@triton.jit
def _win_dout(D,g,oc,t,tr,tc,F:tl.constexpr,O:tl.constexpr,P:tl.constexpr,Q:tl.constexpr):
    TH:tl.constexpr=((P+1)//2);TW:tl.constexpr=((Q+1)//2)
    f=t//(TH*TW);y=t//TW%TH*2;x=t%TW*2
    base=((g*F+f)*O+oc)*P*Q+y*Q+x
    valid=(f<F)&(oc<O)
    a=tl.load(D+base,valid&(y<P)&(x<Q)&(tr!=3)&(tc!=3),0)
    b=tl.load(D+base+1,valid&(y<P)&(x+1<Q)&(tr!=3)&(tc!=0),0)
    c=tl.load(D+base+Q,valid&(y+1<P)&(x<Q)&(tr!=0)&(tc!=3),0)
    d=tl.load(D+base+Q+1,valid&(y+1<P)&(x+1<Q)&(tr!=0)&(tc!=0),0)
    sr=tl.where(tr==2,-1.,1.);sc=tl.where(tc==2,-1.,1.)
    return a+sc*b+sr*c+sr*sc*d

@triton.jit
def _win_gw_out(U,Y,G:tl.constexpr,O:tl.constexpr,C:tl.constexpr,SK:tl.constexpr,BLOCK:tl.constexpr):
    i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK);g=i//(O*C);j=i%(O*C)
    valid=i<G*O*C
    u0=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u0+=tl.load(U+((g*SK+part)*16+0)*O*C+j,valid,0)
    u1=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u1+=tl.load(U+((g*SK+part)*16+1)*O*C+j,valid,0)
    u2=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u2+=tl.load(U+((g*SK+part)*16+2)*O*C+j,valid,0)
    u3=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u3+=tl.load(U+((g*SK+part)*16+3)*O*C+j,valid,0)
    u4=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u4+=tl.load(U+((g*SK+part)*16+4)*O*C+j,valid,0)
    u5=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u5+=tl.load(U+((g*SK+part)*16+5)*O*C+j,valid,0)
    u6=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u6+=tl.load(U+((g*SK+part)*16+6)*O*C+j,valid,0)
    u7=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u7+=tl.load(U+((g*SK+part)*16+7)*O*C+j,valid,0)
    u8=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u8+=tl.load(U+((g*SK+part)*16+8)*O*C+j,valid,0)
    u9=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u9+=tl.load(U+((g*SK+part)*16+9)*O*C+j,valid,0)
    u10=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u10+=tl.load(U+((g*SK+part)*16+10)*O*C+j,valid,0)
    u11=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u11+=tl.load(U+((g*SK+part)*16+11)*O*C+j,valid,0)
    u12=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u12+=tl.load(U+((g*SK+part)*16+12)*O*C+j,valid,0)
    u13=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u13+=tl.load(U+((g*SK+part)*16+13)*O*C+j,valid,0)
    u14=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u14+=tl.load(U+((g*SK+part)*16+14)*O*C+j,valid,0)
    u15=tl.full((BLOCK,),0,tl.float32)
    for part in range(SK):
        u15+=tl.load(U+((g*SK+part)*16+15)*O*C+j,valid,0)
    v0=u0+0.5*(u4+u8)
    v4=0.5*(u4-u8)
    v8=0.5*(u4+u8)+u12
    v1=u1+0.5*(u5+u9)
    v5=0.5*(u5-u9)
    v9=0.5*(u5+u9)+u13
    v2=u2+0.5*(u6+u10)
    v6=0.5*(u6-u10)
    v10=0.5*(u6+u10)+u14
    v3=u3+0.5*(u7+u11)
    v7=0.5*(u7-u11)
    v11=0.5*(u7+u11)+u15
    tl.store(Y+i*9+0,v0+0.5*(v1+v2),valid)
    tl.store(Y+i*9+1,0.5*(v1-v2),valid)
    tl.store(Y+i*9+2,0.5*(v1+v2)+v3,valid)
    tl.store(Y+i*9+3,v4+0.5*(v5+v6),valid)
    tl.store(Y+i*9+4,0.5*(v5-v6),valid)
    tl.store(Y+i*9+5,0.5*(v5+v6)+v7,valid)
    tl.store(Y+i*9+6,v8+0.5*(v9+v10),valid)
    tl.store(Y+i*9+7,0.5*(v9-v10),valid)
    tl.store(Y+i*9+8,0.5*(v9+v10)+v11,valid)


def _packed_configs():
    # Small SIMT tiles; resource-checked offline for sm86. No transformed gathers
    # or two simultaneous accumulators in the GEMM mainloop.
    return [triton.Config(dict(BM=m,BN=n,BK=k),num_warps=w,num_stages=2)
            for m,n,k,w in [(16,32,16,4),(32,32,16,4),(32,64,16,4),(32,64,32,4),(64,32,16,4),(64,64,16,4),(64,64,32,4),(16,64,32,4)]]

@triton.jit
def _pack_tiles(X,V,start,G:tl.constexpr,F:tl.constexpr,C:tl.constexpr,H:tl.constexpr,W:tl.constexpr,
                P:tl.constexpr,Q:tl.constexpr,PH:tl.constexpr,PW:tl.constexpr,NT:tl.constexpr,
                DOUT:tl.constexpr,BLOCK:tl.constexpr):
    i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK)
    g=tl.program_id(1);z=tl.program_id(2);ci=i//NT;n=i%NT;t=start+n
    if DOUT:
        v=_win_dout(X,g,ci,t,z//4,z%4,F,C,H,W)
    else:
        v=_win_input(X,g,ci,t,z//4,z%4,F,C,H,W,(P+1)//2,(Q+1)//2,PH,PW)
    tl.store(V+((z*G+g)*C+ci)*NT+n,v,ci<C)

@triton.autotune(configs=_packed_configs(),key=['G','C','O','NT','ADD','PREC'])
@triton.jit
def _packed_conv(U,V,M,G:tl.constexpr,C:tl.constexpr,O:tl.constexpr,NT:tl.constexpr,
                 ADD:tl.constexpr,PREC:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    pid=tl.program_id(0);g=tl.program_id(1);z=tl.program_id(2)
    nn=tl.cdiv(NT,BN);nm=tl.cdiv(O,BM)
    first=pid//(4*nn)*4;count=tl.minimum(nm-first,4)
    oc=(first+pid%(4*nn)%count)*BM+tl.arange(0,BM)
    n=(pid%(4*nn)//count)*BN+tl.arange(0,BN);kk=tl.arange(0,BK)
    acc=tl.zeros((BM,BN),tl.float32)
    for cb in range(tl.cdiv(C,BK)):
        ci=cb*BK+kk
        a=tl.load(U+((z*G+g)*O+oc[:,None])*C+ci[None,:],(oc[:,None]<O)&(ci[None,:]<C),0)
        b=tl.load(V+((z*G+g)*C+ci[:,None])*NT+n[None,:],(ci[:,None]<C)&(n[None,:]<NT),0)
        acc=tl.dot(a,b,acc,input_precision=PREC)
    off=((z*G+g)*O+oc[:,None])*NT+n[None,:];mask=(oc[:,None]<O)&(n[None,:]<NT)
    if ADD:acc+=tl.load(M+off,mask,0)
    tl.store(M+off,acc,mask)

@triton.autotune(configs=_packed_configs(),key=['G','C','O','NT','PREC'])
@triton.jit
def _packed_gw(V,D,U,G:tl.constexpr,C:tl.constexpr,O:tl.constexpr,NT:tl.constexpr,
               PREC:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    pid=tl.program_id(0);g=tl.program_id(1);z=tl.program_id(2)
    oc=pid//tl.cdiv(C,BN)*BM+tl.arange(0,BM);ci=pid%tl.cdiv(C,BN)*BN+tl.arange(0,BN)
    kk=tl.arange(0,BK);acc=tl.zeros((BM,BN),tl.float32)
    for kb in range(tl.cdiv(NT,BK)):
        k=kb*BK+kk
        a=tl.load(D+((z*G+g)*O+oc[:,None])*NT+k[None,:],(oc[:,None]<O)&(k[None,:]<NT),0)
        b=tl.load(V+((z*G+g)*C+ci[None,:])*NT+k[:,None],(ci[None,:]<C)&(k[:,None]<NT),0)
        acc=tl.dot(a,b,acc,input_precision=PREC)
    tl.store(U+((g*16+z)*O+oc[:,None])*C+ci[None,:],acc,(oc[:,None]<O)&(ci[None,:]<C))

@triton.jit
def _accumulate(U,Sum,Corr,N:tl.constexpr,FIRST:tl.constexpr,BLOCK:tl.constexpr):
    i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK);valid=i<N
    v=tl.load(U+i,valid,0)
    if FIRST:
        updated=v;corr=tl.full((BLOCK,),0,tl.float32)
    else:
        old=tl.load(Sum+i,valid,0);prev=tl.load(Corr+i,valid,0)
        delta=v-prev;updated=old+delta;corr=(updated-old)-delta
    tl.store(Sum+i,updated,valid);tl.store(Corr+i,corr,valid)


def _v5_winograd_plan(g,f,c,o,h,w,p,q,r,s,sh,sw,ph,pw,dh,dw,dtype,budget,algorithm='auto',split_k=None):
    """Explicit experimental path only. auto stays on measured implicit kernels.
    Workspace counts all simultaneously live packed tensors, excluding outputs.
    Outer group batching prevents workspace growth with G. split_k applies only
    to implicit fallback; packed gW uses streamed tiles and compensated summation.
    """
    supported=dtype==torch.float32 and (r,s,sh,sw,dh,dw)==(3,3,1,1,1,1) and 0<=ph<=2 and 0<=pw<=2
    if algorithm=='winograd' and not supported:raise ValueError('Winograd requires FP32, 3x3, stride=dilation=1, padding<=2')
    use=supported and algorithm=='winograd'
    budget=min(budget,(2**30-1)*4)
    # Bounded K=NT also limits each FP32 gW reduction before compensated summation.
    def choose(cin,cout,total,weight_copies):
        if not use:return (0,0,0)
        cap=min(1024,max(32,triton.next_power_of_2(total)))
        choices=[]
        for nt in [cap//(2**i) for i in range(cap.bit_length()-5)]:
            per=64*(weight_copies*cin*cout+(cin+cout)*nt)
            if per<=budget:
                gb=min(g,max(1,budget//per))
                launches=triton.cdiv(g,gb)*triton.cdiv(total,nt)
                choices.append((launches,-gb,-nt,nt,gb,per*gb))
        return min(choices)[3:] if choices else (0,0,0)
    nt0,gb0,b0=choose(c,o,f*triton.cdiv(p,2)*triton.cdiv(q,2),2)
    nt1,gb1,b1=choose(o,c,f*triton.cdiv(h,2)*triton.cdiv(w,2),1)
    ntw,gbw,bw=choose(c,o,f*triton.cdiv(p,2)*triton.cdiv(q,2),3)
    return dict(ggO_nt=nt0,gI_nt=nt1,gW_split=1 if ntw else 0,gW_nt=ntw,
                ggO_groups=gb0,gI_groups=gb1,gW_groups=gbw,
                ggO_pack=bool(nt0),gI_pack=bool(nt1),scratch_bytes=max(b0,b1,bw))


def _packed_forward(x,wt,ai,aw,bias,out,nt,group_batch,ph,pw,hi,hw,flip,precision):
    g,f,c,h,w=x.shape;_,_,o,p,q=out.shape
    total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    for base in range(0,g,group_batch):
        end=min(g,base+group_batch);gb=end-base
        weights=[];sources=[]
        if hi:weights.append(wt[base:end]);sources.append(ai[base:end])
        if hw:weights.append(aw[base:end]);sources.append(x[base:end])
        us=[]
        for weight in weights:
            u=torch.empty((16,gb,o,c),device=x.device,dtype=torch.float32)
            _win_weight_pack[(triton.cdiv(o,16)*triton.cdiv(c,32),gb,16)](weight,u,gb,c,o,flip)
            us.append(u)
        v=torch.empty((16,gb,c,nt),device=x.device,dtype=torch.float32)
        m=torch.empty((16,gb,o,nt),device=x.device,dtype=torch.float32)
        for start in range(0,total,nt):
            for term,(source,u) in enumerate(zip(sources,us)):
                _pack_tiles[(triton.cdiv(c*nt,256),gb,16)](source,v,start,gb,f,c,h,w,p,q,ph,pw,nt,False,256)
                # Separate output buffers are unnecessary: the second term adds to M.
                # Tune overwrite mode only; reuse its config for in-place addition.
                _launch_packed_conv(u,v,m,gb,c,o,nt,term!=0,precision)
            _win_out[(triton.cdiv(gb*o*nt,128),)](m,bias[base:end] if bias is not None else x,out[base:end],start,gb,f,o,p,q,nt,bias is not None,128)
        # Do not retain the previous group's workspaces during next allocation.
        del us,u,v,m


def _launch_packed_conv(u,v,m,g,c,o,nt,add,precision):
    grid=lambda meta:(triton.cdiv(o,meta['BM'])*triton.cdiv(nt,meta['BN']),g,16)
    if not add:
        _packed_conv[grid](u,v,m,g,c,o,nt,False,precision)
    else:
        # Avoid in-place autotune corruption: use the already measured overwrite
        # configuration. No input/output values are retained between API calls.
        cfg=_packed_conv.best_config
        _packed_conv.fn[grid](u,v,m,g,c,o,nt,True,precision,**cfg.kwargs,num_warps=cfg.num_warps,num_stages=cfg.num_stages)


def _packed_weight_grad(ai,d,out,nt,group_batch,ph,pw,precision):
    g,f,c,h,w=ai.shape;_,_,o,p,q=d.shape
    total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    for base in range(0,g,group_batch):
        end=min(g,base+group_batch);gb=end-base
        v=torch.empty((16,gb,c,nt),device=ai.device,dtype=torch.float32)
        dv=torch.empty((16,gb,o,nt),device=ai.device,dtype=torch.float32)
        u=torch.empty((gb,16,o,c),device=ai.device,dtype=torch.float32)
        acc=torch.empty_like(u);corr=torch.empty_like(u)
        ne=gb*16*o*c
        for start in range(0,total,nt):
            _pack_tiles[(triton.cdiv(c*nt,256),gb,16)](ai[base:end],v,start,gb,f,c,h,w,p,q,ph,pw,nt,False,256)
            _pack_tiles[(triton.cdiv(o*nt,256),gb,16)](d[base:end],dv,start,gb,f,o,p,q,p,q,0,0,nt,True,256)
            _packed_gw[lambda meta:(triton.cdiv(o,meta['BM'])*triton.cdiv(c,meta['BN']),gb,16)](v,dv,u,gb,c,o,nt,precision)
            _accumulate[(triton.cdiv(ne,256),)](u,acc,corr,ne,start==0,256,enable_fp_fusion=False)
        _win_gw_out[(triton.cdiv(gb*o*c,64),)](acc,out[base:end],gb,o,c,1,64)
        del v,dv,u,acc,corr

def _pair(x):
    if isinstance(x,int): return (x,x)
    x=tuple(x)
    if len(x)==1: x=x*2
    if len(x)!=2 or any(not isinstance(v,int) for v in x): raise ValueError('Expected int or 1/2 integer sequence')
    return x


def workspace_split(g,f,c,o,r,s,p,q,num_sms,budget_bytes):
    """Bounded heuristic, not a measured optimum. No workspace for split=1."""
    tiles=g*triton.cdiv(o,32)*triton.cdiv(c*r*s,64)
    occupancy=max(1,triton.cdiv(2*num_sms,tiles))
    # Also bound long per-CTA reductions, even when G already supplies many CTAs.
    length=max(1,triton.cdiv(f*p*q,2048))
    want=min(16,max(occupancy,length),max(1,(f*p*q)//256))
    split=1
    while split*2<=want: split*=2
    per=g*o*c*r*s*4
    while split>1 and per*split>budget_bytes: split//=2
    return split


def convolution_double_backward(ggI_opt,ggW_r_opt,ggb_opt,gO_r,weight_r,input,
        stride_,padding_,dilation_,transposed_,output_padding_,groups_,output_mask,
        *,precision='ieee',workspace_limit_mb=32,split_k=None,compute=(True,True,True),algorithm='auto'):
    """ATen argument order; tensors have explicit leading independent group G.

    input/ggI [G,F,C,H,W]; weight/ggW [G,O,C,R,S]; gO [G,F,O,P,Q]; ggb [G,O].
    groups_=1 means dense convolution INSIDE each independent outer group.
    Returns (ggO,gI,gW), missing terms are None. Matches PyTorch 2.5.1's
    ignored output_mask; use optional ggI/ggW/ggb=None to omit terms.
    Non-transposed 2D only. No autograd graph; no retained tensor state.
    compute selects (ggO,gI,gW) explicitly for profiling; default computes all.
    algorithm=auto and implicit retain the generic path. winograd_large selects
    the v9 large-batch candidate (explicit opt-in); winograd_v8 is unchanged v8.
    Explicit winograd
    selects the experimental v8 path; winograd_v7/v6 preserve prior versions, v5 the
    old packed implementation. winograd_joint/separate force v8 scheduling.
    split_k controls gW partial sums; auto remains the original implicit path.
    Workspace bounds apply to execution buffers; first-use autotuning may clone
    accumulator buffers to restore their values between candidate trials. It keeps
    FP32 arithmetic but changes summation order; it is not bitwise ATen-equivalent.
    """
    if transposed_ or groups_!=1 or _pair(output_padding_)!=(0,0):
        raise NotImplementedError('Only transposed=False, output_padding=0, inner groups=1; outer G inferred from input')
    if len(output_mask)!=3: raise ValueError('output_mask must have 3 entries')
    if input.ndim!=5 or weight_r.ndim!=5: raise ValueError('Expected 5D group-first input/weight')
    g,f,c,h,w=input.shape; gw,o,cw,r,s=weight_r.shape
    sh,sw=_pair(stride_); ph,pw=_pair(padding_); dh,dw=_pair(dilation_)
    if min(*input.shape,*weight_r.shape,sh,sw,dh,dw)<=0 or min(ph,pw)<0 or (g,c)!=(gw,cw):
        raise ValueError('Invalid dimensions or convolution parameters')
    p=(h+2*ph-dh*(r-1)-1)//sh+1; q=(w+2*pw-dw*(s-1)-1)//sw+1
    if min(p,q)<=0 or tuple(gO_r.shape)!=(g,f,o,p,q): raise ValueError('Invalid gO shape')
    for t,shape in [(ggI_opt,input.shape),(ggW_r_opt,weight_r.shape),(ggb_opt,(g,o))]:
        if t is not None and tuple(t.shape)!=tuple(shape): raise ValueError('Optional tensor shape mismatch')
    ts=[input,weight_r,gO_r]+[t for t in (ggI_opt,ggW_r_opt,ggb_opt) if t is not None]
    if input.dtype not in (torch.float32,torch.float16,torch.bfloat16): raise TypeError('FP32/FP16/BF16 required')
    for t in ts:
        if not t.is_cuda or t.device!=input.device or t.dtype!=input.dtype or not t.is_contiguous():
            raise ValueError('All inputs must be contiguous, same CUDA device/dtype')
        if torch.is_grad_enabled() and t.requires_grad: raise RuntimeError('Stateless manual derivative: call under torch.no_grad()')
    if max(t.numel() for t in ts)>=2**30 or g*f>65535: raise ValueError('Shape exceeds conservative indexing/grid limits')
    if precision not in ('ieee','tf32','tf32x3'): raise ValueError('Unsupported precision')
    if workspace_limit_mb<0: raise ValueError('Negative workspace budget')
    if len(compute)!=3: raise ValueError('compute must contain three flags')
    if algorithm not in ('auto','implicit','winograd','winograd_v5','winograd_v6','winograd_v7','winograd_v8','winograd_large','winograd_joint','winograd_separate'):raise ValueError('Invalid algorithm')
    plan=winograd_plan(g,f,c,o,h,w,p,q,r,s,sh,sw,ph,pw,dh,dw,input.dtype,int(workspace_limit_mb*1024**2),algorithm,split_k)
    ggO=gI=gW=None
    with torch.cuda.device(input.device):
        dims=(g,f,c,h,w,o,r,s,p,q,sh,sw,ph,pw,dh,dw,precision)
        hi=ggI_opt is not None; hw=ggW_r_opt is not None; hb=ggb_opt is not None
        v6=plan.get('version') in (6,7,8,9)
        v7=plan.get('version') in (7,8,9)
        forward=_forward7 if v7 else (_forward6 if v6 else _packed_forward)
        joint=_joint9 if plan.get('version')==9 else (_joint8 if plan.get('version')==8 else (_joint7 if v7 else _joint6))
        weight_grad=_weight_grad7 if v7 else _weight_grad6
        if v6 and hi and compute[0] and compute[2] and plan['joint_nt']:
            ggO=torch.empty_like(gO_r);gW=torch.empty_like(weight_r)
            joint(input,weight_r,ggI_opt,ggW_r_opt,ggb_opt,gO_r,ggO,gW,plan['joint_nt'],plan['joint_groups'],plan['gW_split'],ph,pw,precision)
            compute=(False,compute[1],False)
        if compute[0] and (hi or hw or hb):
            ggO=torch.empty_like(gO_r)
            if plan['ggO_nt'] and (hi or hw):
                forward(input,weight_r,ggI_opt if hi else input,ggW_r_opt if hw else weight_r,ggb_opt,ggO,plan['ggO_nt'],plan['ggO_groups'],ph,pw,hi,hw,False,precision)
            else:
                _ggo[lambda m:(triton.cdiv(o,m['BM'])*triton.cdiv(f*p*q if m['BATCH_FOLD'] else p*q,m['BN']),g if m['BATCH_FOLD'] else g*f)](
                input,weight_r,ggI_opt if hi else input,ggW_r_opt if hw else weight_r,
                ggb_opt if hb else input,ggO,*dims,hi,hw,hb)
        if compute[1] and hw:
            gI=torch.empty_like(input)
            if plan['gI_nt']:
                forward(gO_r,ggW_r_opt,gO_r,ggW_r_opt,None,gI,plan['gI_nt'],plan['gI_groups'],2-ph,2-pw,True,False,True,precision)
            else:
                _gi[lambda m:(triton.cdiv(c,m['BM'])*triton.cdiv(f*h*w if m['BATCH_FOLD'] else h*w,m['BN']),g if m['BATCH_FOLD'] else g*f)](gO_r,ggW_r_opt,gI,*dims)
        if compute[2] and hi:
            if plan['gW_split']:
                gW=torch.empty_like(weight_r)
                if v6:weight_grad(ggI_opt,gO_r,gW,plan['gW_nt'],plan['gW_groups'],plan['gW_split'],ph,pw,precision)
                else:_packed_weight_grad(ggI_opt,gO_r,gW,plan['gW_nt'],plan['gW_groups'],ph,pw,precision)
            else:
                budget=int(workspace_limit_mb*1024**2)
                sk=workspace_split(g,f,c,o,r,s,p,q,torch.cuda.get_device_properties(input.device).multi_processor_count,budget) if split_k is None else split_k
                if sk not in (1,2,4,8,16) or g*sk>65535: raise ValueError('Invalid split_k')
                ne=g*o*c*r*s
                if sk>1 and (ne*sk*4>budget or ne*sk>=2**30): raise ValueError('Split-K exceeds workspace/indexing budget')
                gW=torch.empty_like(weight_r)
                tmp=torch.empty((g,sk,o,c,r,s),device=input.device,dtype=torch.float32) if sk>1 else gW
                _gw[lambda m:(r*s*triton.cdiv(c,m['BM'])*triton.cdiv(o,m['BN']) if m['FIXED_RS'] else triton.cdiv(o,m['BM'])*triton.cdiv(c*r*s,m['BN']),g*sk)](ggI_opt,gO_r,tmp,*dims,sk)
                if sk>1: _reduce[(triton.cdiv(ne,256),)](tmp,gW,ne,o*c*r*s,sk,256)
    return ggO,gI,gW

_convolution_double_backward=convolution_double_backward


@triton.jit
def _pack_tiles_all(X,V,start,G:tl.constexpr,F:tl.constexpr,C:tl.constexpr,H:tl.constexpr,W:tl.constexpr,
                    P:tl.constexpr,Q:tl.constexpr,PH:tl.constexpr,PW:tl.constexpr,NT:tl.constexpr,
                    DOUT:tl.constexpr,BLOCK:tl.constexpr):
    i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK);g=tl.program_id(1)
    ci=i//NT;n=i%NT;t=start+n
    f=t//(((P+1)//2)*((Q+1)//2));y=t//((Q+1)//2)%((P+1)//2)*2;x=t%((Q+1)//2)*2
    if not DOUT:y-=PH;x-=PW
    base=((g*F+f)*C+ci)*H*W
    valid=(ci<C)&(f<F)

    if DOUT:
        d00=tl.load(X+base+(y+0)*W+x+0,valid&(y+0>=0)&(y+0<H)&(x+0>=0)&(x+0<W),0)
        d01=tl.load(X+base+(y+0)*W+x+1,valid&(y+0>=0)&(y+0<H)&(x+1>=0)&(x+1<W),0)
        d10=tl.load(X+base+(y+1)*W+x+0,valid&(y+1>=0)&(y+1<H)&(x+0>=0)&(x+0<W),0)
        d11=tl.load(X+base+(y+1)*W+x+1,valid&(y+1>=0)&(y+1<H)&(x+1>=0)&(x+1<W),0)
        a00=d00
        a10=d00+d10
        a20=d00-d10
        a30=d10
        a01=d01
        a11=d01+d11
        a21=d01-d11
        a31=d11
        v00=a00
        v01=a00+a01
        v02=a00-a01
        v03=a01
        v10=a10
        v11=a10+a11
        v12=a10-a11
        v13=a11
        v20=a20
        v21=a20+a21
        v22=a20-a21
        v23=a21
        v30=a30
        v31=a30+a31
        v32=a30-a31
        v33=a31
    else:
        d00=tl.load(X+base+(y+0)*W+x+0,valid&(y+0>=0)&(y+0<H)&(x+0>=0)&(x+0<W),0)
        d01=tl.load(X+base+(y+0)*W+x+1,valid&(y+0>=0)&(y+0<H)&(x+1>=0)&(x+1<W),0)
        d02=tl.load(X+base+(y+0)*W+x+2,valid&(y+0>=0)&(y+0<H)&(x+2>=0)&(x+2<W),0)
        d03=tl.load(X+base+(y+0)*W+x+3,valid&(y+0>=0)&(y+0<H)&(x+3>=0)&(x+3<W),0)
        d10=tl.load(X+base+(y+1)*W+x+0,valid&(y+1>=0)&(y+1<H)&(x+0>=0)&(x+0<W),0)
        d11=tl.load(X+base+(y+1)*W+x+1,valid&(y+1>=0)&(y+1<H)&(x+1>=0)&(x+1<W),0)
        d12=tl.load(X+base+(y+1)*W+x+2,valid&(y+1>=0)&(y+1<H)&(x+2>=0)&(x+2<W),0)
        d13=tl.load(X+base+(y+1)*W+x+3,valid&(y+1>=0)&(y+1<H)&(x+3>=0)&(x+3<W),0)
        d20=tl.load(X+base+(y+2)*W+x+0,valid&(y+2>=0)&(y+2<H)&(x+0>=0)&(x+0<W),0)
        d21=tl.load(X+base+(y+2)*W+x+1,valid&(y+2>=0)&(y+2<H)&(x+1>=0)&(x+1<W),0)
        d22=tl.load(X+base+(y+2)*W+x+2,valid&(y+2>=0)&(y+2<H)&(x+2>=0)&(x+2<W),0)
        d23=tl.load(X+base+(y+2)*W+x+3,valid&(y+2>=0)&(y+2<H)&(x+3>=0)&(x+3<W),0)
        d30=tl.load(X+base+(y+3)*W+x+0,valid&(y+3>=0)&(y+3<H)&(x+0>=0)&(x+0<W),0)
        d31=tl.load(X+base+(y+3)*W+x+1,valid&(y+3>=0)&(y+3<H)&(x+1>=0)&(x+1<W),0)
        d32=tl.load(X+base+(y+3)*W+x+2,valid&(y+3>=0)&(y+3<H)&(x+2>=0)&(x+2<W),0)
        d33=tl.load(X+base+(y+3)*W+x+3,valid&(y+3>=0)&(y+3<H)&(x+3>=0)&(x+3<W),0)
        a00=d00-d02
        a01=d01+d02
        a02=d02-d01
        a03=d03-d01
        a10=d10-d12
        a11=d11+d12
        a12=d12-d11
        a13=d13-d11
        a20=d20-d22
        a21=d21+d22
        a22=d22-d21
        a23=d23-d21
        a30=d30-d32
        a31=d31+d32
        a32=d32-d31
        a33=d33-d31
        v00=a00-a20
        v10=a10+a20
        v20=a20-a10
        v30=a30-a10
        v01=a01-a21
        v11=a11+a21
        v21=a21-a11
        v31=a31-a11
        v02=a02-a22
        v12=a12+a22
        v22=a22-a12
        v32=a32-a12
        v03=a03-a23
        v13=a13+a23
        v23=a23-a13
        v33=a33-a13
    tl.store(V+((0*G+g)*C+ci)*NT+n,v00,ci<C)
    tl.store(V+((1*G+g)*C+ci)*NT+n,v01,ci<C)
    tl.store(V+((2*G+g)*C+ci)*NT+n,v02,ci<C)
    tl.store(V+((3*G+g)*C+ci)*NT+n,v03,ci<C)
    tl.store(V+((4*G+g)*C+ci)*NT+n,v10,ci<C)
    tl.store(V+((5*G+g)*C+ci)*NT+n,v11,ci<C)
    tl.store(V+((6*G+g)*C+ci)*NT+n,v12,ci<C)
    tl.store(V+((7*G+g)*C+ci)*NT+n,v13,ci<C)
    tl.store(V+((8*G+g)*C+ci)*NT+n,v20,ci<C)
    tl.store(V+((9*G+g)*C+ci)*NT+n,v21,ci<C)
    tl.store(V+((10*G+g)*C+ci)*NT+n,v22,ci<C)
    tl.store(V+((11*G+g)*C+ci)*NT+n,v23,ci<C)
    tl.store(V+((12*G+g)*C+ci)*NT+n,v30,ci<C)
    tl.store(V+((13*G+g)*C+ci)*NT+n,v31,ci<C)
    tl.store(V+((14*G+g)*C+ci)*NT+n,v32,ci<C)
    tl.store(V+((15*G+g)*C+ci)*NT+n,v33,ci<C)


def _gw6_configs():
    return [triton.Config(dict(BM=m,BN=n,BK=k),num_warps=w,num_stages=2)
            for m,n,k,w in [(16,64,32,4),(32,32,32,4),(32,64,32,4),(64,32,32,4),
                           (64,64,32,4),(32,64,64,4),(64,64,16,4),(32,128,32,8)]]

@triton.autotune(configs=_gw6_configs(),key=['G','C','O','NT','SK','FIRST','PREC'],restore_value=['Sum','Corr'])
@triton.jit
def _packed_gw_acc(V,D,Sum,Corr,G:tl.constexpr,C:tl.constexpr,O:tl.constexpr,NT:tl.constexpr,
                   SK:tl.constexpr,FIRST:tl.constexpr,PREC:tl.constexpr,
                   BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    pid=tl.program_id(0);g=tl.program_id(1);zs=tl.program_id(2);z=zs%16;part=zs//16
    oc=pid//tl.cdiv(C,BN)*BM+tl.arange(0,BM);ci=pid%tl.cdiv(C,BN)*BN+tl.arange(0,BN)
    kk=tl.arange(0,BK);acc=tl.zeros((BM,BN),tl.float32)
    for kb in range(tl.cdiv(NT,SK*BK)):
        k=(kb*SK+part)*BK+kk
        a=tl.load(D+((z*G+g)*O+oc[:,None])*NT+k[None,:],(oc[:,None]<O)&(k[None,:]<NT),0)
        b=tl.load(V+((z*G+g)*C+ci[None,:])*NT+k[:,None],(ci[None,:]<C)&(k[:,None]<NT),0)
        acc=tl.dot(a,b,acc,input_precision=PREC)
    off=(((g*SK+part)*16+z)*O+oc[:,None])*C+ci[None,:]
    valid=(oc[:,None]<O)&(ci[None,:]<C)
    if FIRST:
        updated=acc;corr=tl.zeros((BM,BN),tl.float32)
    else:
        old=tl.load(Sum+off,valid,0);prev=tl.load(Corr+off,valid,0)
        delta=acc-prev;updated=old+delta;corr=(updated-old)-delta
    tl.store(Sum+off,updated,valid);tl.store(Corr+off,corr,valid)


def _v6_winograd_plan(g,f,c,o,h,w,p,q,r,s,sh,sw,ph,pw,dh,dw,dtype,budget,algorithm='auto',split_k=None):
    if algorithm=='winograd_v5':
        return dict(_v5_winograd_plan(g,f,c,o,h,w,p,q,r,s,sh,sw,ph,pw,dh,dw,dtype,budget,'winograd',split_k),version=5)
    supported=dtype==torch.float32 and (r,s,sh,sw,dh,dw)==(3,3,1,1,1,1) and 0<=ph<=2 and 0<=pw<=2
    if algorithm=='winograd' and not supported:raise ValueError('Winograd requires FP32 3x3 stride=dilation=1 padding<=2')
    use=supported and algorithm=='winograd'
    sk=1 if split_k is None else split_k
    if sk not in (1,2,4,8,16):raise ValueError('Invalid split_k')
    budget=min(budget,(2**30-1)*4)
    def choose(total,fixed,per_tile):
        if not use:return 0,0,0
        # 1024 lost on A5000 in the measured conv2 workload. Keep a bounded
        # target; extra budget increases group capacity, not reduction length.
        nt=min(512 if g<=2 else 256,max(32,512//sk),max(32,triton.next_power_of_2(total)))
        while nt>=32:
            per=64*(fixed+per_tile*nt)
            if per<=budget:
                gb=min(g,4,budget//per)
                return nt,gb,per*gb
            nt//=2
        return 0,0,0
    total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    nt0,gb0,b0=choose(total,2*c*o,c+o)
    nt1,gb1,b1=choose(f*triton.cdiv(h,2)*triton.cdiv(w,2),c*o,c+o)
    ntw,gbw,bw=choose(total,2*sk*c*o,c+o)
    ntj,gbj,bj=choose(total,(2+2*sk)*c*o,c+2*o)
    return dict(version=6,ggO_nt=nt0,gI_nt=nt1,gW_split=sk if ntw else 0,gW_nt=ntw,
                ggO_groups=gb0,gI_groups=gb1,gW_groups=gbw,ggO_pack=bool(nt0),gI_pack=bool(nt1),
                joint_nt=ntj,joint_groups=gbj,scratch_bytes=max(b0,b1,bw,bj))


def _pack6(x,v,start,g,f,c,h,w,p,q,ph,pw,nt,dout=False):
    _pack_tiles_all[(triton.cdiv(c*nt,128),g)](x,v,start,g,f,c,h,w,p,q,ph,pw,nt,dout,128)


def _gw6(v,d,acc,corr,g,c,o,nt,sk,first,precision):
    _packed_gw_acc[lambda m:(triton.cdiv(o,m['BM'])*triton.cdiv(c,m['BN']),g,16*sk)](
        v,d,acc,corr,g,c,o,nt,sk,first,precision,enable_fp_fusion=False)


def _joint6(x,w,ai,aw,bias,d,out,gw,nt,group_batch,sk,ph,pw,precision):
    """Reuse transformed ggI for ggO and gW. One bounded group/tile chunk.
    ggO = conv(ggI,w) + conv(x,ggW) + ggb; gW = wgrad(ggI,gO).
    The ggI buffer can be overwritten by x after gW consumes it.
    """
    g,f,c,h,wi=x.shape;_,_,o,p,q=d.shape;total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    for base in range(0,g,group_batch):
        end=min(g,base+group_batch);gb=end-base
        u1=torch.empty((16,gb,o,c),device=x.device,dtype=torch.float32)
        _win_weight_pack[(triton.cdiv(o,16)*triton.cdiv(c,32),gb,16)](w[base:end],u1,gb,c,o,False)
        u2=None
        if aw is not None:
            u2=torch.empty_like(u1)
            _win_weight_pack[(triton.cdiv(o,16)*triton.cdiv(c,32),gb,16)](aw[base:end],u2,gb,c,o,False)
        v=torch.empty((16,gb,c,nt),device=x.device,dtype=torch.float32)
        dv=torch.empty((16,gb,o,nt),device=x.device,dtype=torch.float32)
        m=torch.empty_like(dv)
        acc=torch.empty((gb,sk,16,o,c),device=x.device,dtype=torch.float32);corr=torch.empty_like(acc)
        for start in range(0,total,nt):
            _pack6(ai[base:end],v,start,gb,f,c,h,wi,p,q,ph,pw,nt)
            _launch_packed_conv(u1,v,m,gb,c,o,nt,False,precision)
            _pack6(d[base:end],dv,start,gb,f,o,p,q,p,q,0,0,nt,True)
            _gw6(v,dv,acc,corr,gb,c,o,nt,sk,start==0,precision)
            if aw is not None:
                _pack6(x[base:end],v,start,gb,f,c,h,wi,p,q,ph,pw,nt)
                _launch_packed_conv(u2,v,m,gb,c,o,nt,True,precision)
            _win_out[(triton.cdiv(gb*o*nt,128),)](m,bias[base:end] if bias is not None else x,out[base:end],start,gb,f,o,p,q,nt,bias is not None,128)
        _win_gw_out[(triton.cdiv(gb*o*c,64),)](acc,gw[base:end],gb,o,c,sk,64)
        del u1,u2,v,dv,m,acc,corr


def _weight_grad6(ai,d,out,nt,group_batch,sk,ph,pw,precision):
    g,f,c,h,w=ai.shape;_,_,o,p,q=d.shape;total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    for base in range(0,g,group_batch):
        end=min(g,base+group_batch);gb=end-base
        v=torch.empty((16,gb,c,nt),device=ai.device,dtype=torch.float32)
        dv=torch.empty((16,gb,o,nt),device=ai.device,dtype=torch.float32)
        acc=torch.empty((gb,sk,16,o,c),device=ai.device,dtype=torch.float32);corr=torch.empty_like(acc)
        for start in range(0,total,nt):
            _pack6(ai[base:end],v,start,gb,f,c,h,w,p,q,ph,pw,nt)
            _pack6(d[base:end],dv,start,gb,f,o,p,q,p,q,0,0,nt,True)
            _gw6(v,dv,acc,corr,gb,c,o,nt,sk,start==0,precision)
        _win_gw_out[(triton.cdiv(gb*o*c,64),)](acc,out[base:end],gb,o,c,sk,64)
        del v,dv,acc,corr

def _forward6(x,wt,ai,aw,bias,out,nt,group_batch,ph,pw,hi,hw,flip,precision):
    g,f,c,h,w=x.shape;_,_,o,p,q=out.shape
    total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    for base in range(0,g,group_batch):
        end=min(g,base+group_batch);gb=end-base
        weights=[];sources=[]
        if hi:weights.append(wt[base:end]);sources.append(ai[base:end])
        if hw:weights.append(aw[base:end]);sources.append(x[base:end])
        us=[]
        for weight in weights:
            u=torch.empty((16,gb,o,c),device=x.device,dtype=torch.float32)
            _win_weight_pack[(triton.cdiv(o,16)*triton.cdiv(c,32),gb,16)](weight,u,gb,c,o,flip)
            us.append(u)
        v=torch.empty((16,gb,c,nt),device=x.device,dtype=torch.float32)
        m=torch.empty((16,gb,o,nt),device=x.device,dtype=torch.float32)
        for start in range(0,total,nt):
            for term,(source,u) in enumerate(zip(sources,us)):
                _pack6(source,v,start,gb,f,c,h,w,p,q,ph,pw,nt)
                # Separate output buffers are unnecessary: the second term adds to M.
                # Tune overwrite mode only; reuse its config for in-place addition.
                _launch_packed_conv(u,v,m,gb,c,o,nt,term!=0,precision)
            _win_out[(triton.cdiv(gb*o*nt,128),)](m,bias[base:end] if bias is not None else x,out[base:end],start,gb,f,o,p,q,nt,bias is not None,128)
        # Do not retain the previous group's workspaces during next allocation.
        del us,u,v,m



def _mm7_configs():
    return [triton.Config(dict(BM=m,BN=n,BK=k),num_warps=w,num_stages=2)
            for m,n,k,w in [(32,64,32,4),(64,64,16,4),(64,64,32,4),
                           (32,128,32,4),(64,128,16,4),(64,128,32,8),
                           (128,32,32,4),(128,64,16,4),(128,64,32,8)]]
@triton.autotune(configs=_mm7_configs(),key=['G','C','O','NT','ADD','PREC'])
@triton.jit
def _packed_conv7(U,V,M,G:tl.constexpr,C:tl.constexpr,O:tl.constexpr,NT:tl.constexpr,
                 ADD:tl.constexpr,PREC:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    pid=tl.program_id(0);g=tl.program_id(1);z=tl.program_id(2)
    nn=tl.cdiv(NT,BN);nm=tl.cdiv(O,BM)
    first=pid//(4*nn)*4;count=tl.minimum(nm-first,4)
    oc=(first+pid%(4*nn)%count)*BM+tl.arange(0,BM)
    n=(pid%(4*nn)//count)*BN+tl.arange(0,BN);kk=tl.arange(0,BK)
    acc=tl.zeros((BM,BN),tl.float32)
    for cb in range(tl.cdiv(C,BK)):
        ci=cb*BK+kk
        a=tl.load(U+((z*G+g)*O+oc[:,None])*C+ci[None,:],(oc[:,None]<O)&(ci[None,:]<C),0)
        b=tl.load(V+((z*G+g)*C+ci[:,None])*NT+n[None,:],(ci[:,None]<C)&(n[None,:]<NT),0)
        acc=tl.dot(a,b,acc,input_precision=PREC)
    off=((z*G+g)*O+oc[:,None])*NT+n[None,:];mask=(oc[:,None]<O)&(n[None,:]<NT)
    if ADD:acc+=tl.load(M+off,mask,0)
    tl.store(M+off,acc,mask)


@triton.jit
def _pack_dout7(X,V,start,G:tl.constexpr,F:tl.constexpr,C:tl.constexpr,
                H:tl.constexpr,W:tl.constexpr,NT:tl.constexpr):
    pid=tl.program_id(0);g=tl.program_id(1)
    ci=(pid//tl.cdiv(NT,32)*16+tl.arange(0,16))[:,None]
    n=(pid%tl.cdiv(NT,32)*32+tl.arange(0,32))[None,:];t=start+n
    f=t//(tl.cdiv(H,2)*tl.cdiv(W,2));y=t//tl.cdiv(W,2)%tl.cdiv(H,2)*2;x=t%tl.cdiv(W,2)*2
    base=((g*F+f)*C+ci)*H*W
    valid=(ci<C)&(f<F)&(n<NT)
    d00=tl.load(X+base+y*W+x,valid&(y<H)&(x<W),0)
    d01=tl.load(X+base+y*W+x+1,valid&(y<H)&(x+1<W),0)
    d10=tl.load(X+base+(y+1)*W+x,valid&(y+1<H)&(x<W),0)
    d11=tl.load(X+base+(y+1)*W+x+1,valid&(y+1<H)&(x+1<W),0)
    a00=d00
    a10=d00+d10
    a20=d00-d10
    a30=d10
    a01=d01
    a11=d01+d11
    a21=d01-d11
    a31=d11
    v00=a00
    v01=a00+a01
    v02=a00-a01
    v03=a01
    v10=a10
    v11=a10+a11
    v12=a10-a11
    v13=a11
    v20=a20
    v21=a20+a21
    v22=a20-a21
    v23=a21
    v30=a30
    v31=a30+a31
    v32=a30-a31
    v33=a31
    tl.store(V+((0*G+g)*NT+n)*C+ci,v00,(ci<C)&(n<NT))
    tl.store(V+((1*G+g)*NT+n)*C+ci,v01,(ci<C)&(n<NT))
    tl.store(V+((2*G+g)*NT+n)*C+ci,v02,(ci<C)&(n<NT))
    tl.store(V+((3*G+g)*NT+n)*C+ci,v03,(ci<C)&(n<NT))
    tl.store(V+((4*G+g)*NT+n)*C+ci,v10,(ci<C)&(n<NT))
    tl.store(V+((5*G+g)*NT+n)*C+ci,v11,(ci<C)&(n<NT))
    tl.store(V+((6*G+g)*NT+n)*C+ci,v12,(ci<C)&(n<NT))
    tl.store(V+((7*G+g)*NT+n)*C+ci,v13,(ci<C)&(n<NT))
    tl.store(V+((8*G+g)*NT+n)*C+ci,v20,(ci<C)&(n<NT))
    tl.store(V+((9*G+g)*NT+n)*C+ci,v21,(ci<C)&(n<NT))
    tl.store(V+((10*G+g)*NT+n)*C+ci,v22,(ci<C)&(n<NT))
    tl.store(V+((11*G+g)*NT+n)*C+ci,v23,(ci<C)&(n<NT))
    tl.store(V+((12*G+g)*NT+n)*C+ci,v30,(ci<C)&(n<NT))
    tl.store(V+((13*G+g)*NT+n)*C+ci,v31,(ci<C)&(n<NT))
    tl.store(V+((14*G+g)*NT+n)*C+ci,v32,(ci<C)&(n<NT))
    tl.store(V+((15*G+g)*NT+n)*C+ci,v33,(ci<C)&(n<NT))
@triton.autotune(configs=_mm7_configs(),key=['G','C','O','NT','SK','FIRST','PREC'],restore_value=['Sum','Corr'])
@triton.jit
def _packed_gw7(V,D,Sum,Corr,G:tl.constexpr,C:tl.constexpr,O:tl.constexpr,NT:tl.constexpr,
                   SK:tl.constexpr,FIRST:tl.constexpr,PREC:tl.constexpr,
                   BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    pid=tl.program_id(0);g=tl.program_id(1);zs=tl.program_id(2);z=zs%16;part=zs//16
    ci=pid//tl.cdiv(O,BN)*BM+tl.arange(0,BM);oc=pid%tl.cdiv(O,BN)*BN+tl.arange(0,BN)
    kk=tl.arange(0,BK);acc=tl.zeros((BM,BN),tl.float32)
    for kb in range(tl.cdiv(NT,SK*BK)):
        k=(kb*SK+part)*BK+kk
        a=tl.load(V+((z*G+g)*C+ci[:,None])*NT+k[None,:],(ci[:,None]<C)&(k[None,:]<NT),0)
        b=tl.load(D+((z*G+g)*NT+k[:,None])*O+oc[None,:],(oc[None,:]<O)&(k[:,None]<NT),0)
        acc=tl.dot(a,b,acc,input_precision=PREC)
    off=(((g*SK+part)*16+z)*O+oc[None,:])*C+ci[:,None]
    valid=(oc[None,:]<O)&(ci[:,None]<C)
    if FIRST:
        updated=acc;corr=tl.zeros((BM,BN),tl.float32)
    else:
        old=tl.load(Sum+off,valid,0);prev=tl.load(Corr+off,valid,0)
        delta=acc-prev;updated=old+delta;corr=(updated-old)-delta
    tl.store(Sum+off,updated,valid);tl.store(Corr+off,corr,valid)


def _pack7(x,v,start,g,f,c,h,w,p,q,ph,pw,nt,dout=False):
    if dout:
        _pack_dout7[(triton.cdiv(c,16)*triton.cdiv(nt,32),g)](x,v,start,g,f,c,h,w,nt)
    else:_pack6(x,v,start,g,f,c,h,w,p,q,ph,pw,nt)


def _gw7(v,d,acc,corr,g,c,o,nt,sk,first,precision):
    _packed_gw7[lambda m:(triton.cdiv(c,m['BM'])*triton.cdiv(o,m['BN']),g,16*sk)](
        v,d,acc,corr,g,c,o,nt,sk,first,precision,enable_fp_fusion=False)

def _launch_conv7(u,v,m,g,c,o,nt,add,precision):
    grid=lambda meta:(triton.cdiv(o,meta['BM'])*triton.cdiv(nt,meta['BN']),g,16)
    if not add:
        _packed_conv7[grid](u,v,m,g,c,o,nt,False,precision)
    else:
        # Avoid in-place autotune corruption: use the already measured overwrite
        # configuration. No input/output values are retained between API calls.
        cfg=_packed_conv7.best_config
        _packed_conv7.fn[grid](u,v,m,g,c,o,nt,True,precision,**cfg.kwargs,num_warps=cfg.num_warps,num_stages=cfg.num_stages)


def _joint7(x,w,ai,aw,bias,d,out,gw,nt,group_batch,sk,ph,pw,precision):
    """Reuse transformed ggI for ggO and gW. One bounded group/tile chunk.
    ggO = conv(ggI,w) + conv(x,ggW) + ggb; gW = wgrad(ggI,gO).
    The ggI buffer can be overwritten by x after gW consumes it.
    """
    g,f,c,h,wi=x.shape;_,_,o,p,q=d.shape;total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    for base in range(0,g,group_batch):
        end=min(g,base+group_batch);gb=end-base
        u1=torch.empty((16,gb,o,c),device=x.device,dtype=torch.float32)
        _win_weight_pack[(triton.cdiv(o,16)*triton.cdiv(c,32),gb,16)](w[base:end],u1,gb,c,o,False)
        u2=None
        if aw is not None:
            u2=torch.empty_like(u1)
            _win_weight_pack[(triton.cdiv(o,16)*triton.cdiv(c,32),gb,16)](aw[base:end],u2,gb,c,o,False)
        v=torch.empty((16,gb,c,nt),device=x.device,dtype=torch.float32)
        dv=torch.empty((16,gb,nt,o),device=x.device,dtype=torch.float32)
        m=torch.empty((16,gb,o,nt),device=x.device,dtype=torch.float32)
        acc=torch.empty((gb,sk,16,o,c),device=x.device,dtype=torch.float32);corr=torch.empty_like(acc)
        for start in range(0,total,nt):
            _pack7(ai[base:end],v,start,gb,f,c,h,wi,p,q,ph,pw,nt)
            _launch_conv7(u1,v,m,gb,c,o,nt,False,precision)
            _pack7(d[base:end],dv,start,gb,f,o,p,q,p,q,0,0,nt,True)
            _gw7(v,dv,acc,corr,gb,c,o,nt,sk,start==0,precision)
            if aw is not None:
                _pack7(x[base:end],v,start,gb,f,c,h,wi,p,q,ph,pw,nt)
                _launch_conv7(u2,v,m,gb,c,o,nt,True,precision)
            _win_out[(triton.cdiv(gb*o*nt,128),)](m,bias[base:end] if bias is not None else x,out[base:end],start,gb,f,o,p,q,nt,bias is not None,128)
        _win_gw_out[(triton.cdiv(gb*o*c,64),)](acc,gw[base:end],gb,o,c,sk,64)
        del u1,u2,v,dv,m,acc,corr


def _weight_grad7(ai,d,out,nt,group_batch,sk,ph,pw,precision):
    g,f,c,h,w=ai.shape;_,_,o,p,q=d.shape;total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    for base in range(0,g,group_batch):
        end=min(g,base+group_batch);gb=end-base
        v=torch.empty((16,gb,c,nt),device=ai.device,dtype=torch.float32)
        dv=torch.empty((16,gb,nt,o),device=ai.device,dtype=torch.float32)
        acc=torch.empty((gb,sk,16,o,c),device=ai.device,dtype=torch.float32);corr=torch.empty_like(acc)
        for start in range(0,total,nt):
            _pack7(ai[base:end],v,start,gb,f,c,h,w,p,q,ph,pw,nt)
            _pack7(d[base:end],dv,start,gb,f,o,p,q,p,q,0,0,nt,True)
            _gw7(v,dv,acc,corr,gb,c,o,nt,sk,start==0,precision)
        _win_gw_out[(triton.cdiv(gb*o*c,64),)](acc,out[base:end],gb,o,c,sk,64)
        del v,dv,acc,corr

def _forward7(x,wt,ai,aw,bias,out,nt,group_batch,ph,pw,hi,hw,flip,precision):
    g,f,c,h,w=x.shape;_,_,o,p,q=out.shape
    total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    for base in range(0,g,group_batch):
        end=min(g,base+group_batch);gb=end-base
        weights=[];sources=[]
        if hi:weights.append(wt[base:end]);sources.append(ai[base:end])
        if hw:weights.append(aw[base:end]);sources.append(x[base:end])
        us=[]
        for weight in weights:
            u=torch.empty((16,gb,o,c),device=x.device,dtype=torch.float32)
            _win_weight_pack[(triton.cdiv(o,16)*triton.cdiv(c,32),gb,16)](weight,u,gb,c,o,flip)
            us.append(u)
        v=torch.empty((16,gb,c,nt),device=x.device,dtype=torch.float32)
        m=torch.empty((16,gb,o,nt),device=x.device,dtype=torch.float32)
        for start in range(0,total,nt):
            for term,(source,u) in enumerate(zip(sources,us)):
                _pack7(source,v,start,gb,f,c,h,w,p,q,ph,pw,nt)
                # Separate output buffers are unnecessary: the second term adds to M.
                # Tune overwrite mode only; reuse its config for in-place addition.
                _launch_conv7(u,v,m,gb,c,o,nt,term!=0,precision)
            _win_out[(triton.cdiv(gb*o*nt,128),)](m,bias[base:end] if bias is not None else x,out[base:end],start,gb,f,o,p,q,nt,bias is not None,128)
        # Do not retain the previous group's workspaces during next allocation.
        del us,u,v,m


def _v7_winograd_plan(g,f,c,o,h,w,p,q,r,s,sh,sw,ph,pw,dh,dw,dtype,budget,algorithm='auto',split_k=None):
    args=(g,f,c,o,h,w,p,q,r,s,sh,sw,ph,pw,dh,dw,dtype,budget)
    if algorithm=='winograd_v6':return _v6_winograd_plan(*args,'winograd',split_k)
    if algorithm not in ('winograd','winograd_joint','winograd_separate'):
        return _v6_winograd_plan(*args,algorithm,split_k)
    plan=_v6_winograd_plan(*args,'winograd',split_k)
    plan['version']=7
    # Explicit, provisional shape/workspace policy. Not a measured global optimum.
    # Share ggI only when it does not increase the number of group chunks.
    joint=bool(plan['joint_nt'])
    if algorithm=='winograd_separate':joint=False
    elif algorithm=='winograd':
        joint=joint and triton.cdiv(g,max(1,plan['joint_groups']))<=triton.cdiv(g,max(1,plan['gW_groups']))
    if not joint:plan['joint_nt']=0;plan['joint_groups']=0
    plan['schedule']='joint' if joint else 'separate'
    return plan


def _dual8_configs():
    return [triton.Config(dict(BM=m,BN=n,BK=k),num_warps=w,num_stages=2)
            for m,n,k,w in [(32,32,32,4),(32,64,32,4),(64,32,32,4),
                           (64,64,16,4),(64,64,32,4),(32,128,32,8)]]


@triton.autotune(configs=_dual8_configs(),key=['G','C','O','NT','PREC'])
@triton.jit
def _packed_dual8(U,V,U2,V2,M,G:tl.constexpr,C:tl.constexpr,O:tl.constexpr,NT:tl.constexpr,
                  PREC:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    pid=tl.program_id(0);g=tl.program_id(1);z=tl.program_id(2)
    nn=tl.cdiv(NT,BN);nm=tl.cdiv(O,BM)
    first=pid//(4*nn)*4;count=tl.minimum(nm-first,4)
    oc=(first+pid%(4*nn)%count)*BM+tl.arange(0,BM)
    n=(pid%(4*nn)//count)*BN+tl.arange(0,BN);kk=tl.arange(0,BK)
    a1=tl.zeros((BM,BN),tl.float32);a2=tl.zeros((BM,BN),tl.float32)
    # Separate accumulators preserve the two contraction sums before addition.
    for cb in range(tl.cdiv(C,BK)):
        ci=cb*BK+kk
        up=((z*G+g)*O+oc[:,None])*C+ci[None,:]
        vp=((z*G+g)*C+ci[:,None])*NT+n[None,:]
        um=(oc[:,None]<O)&(ci[None,:]<C);vm=(ci[:,None]<C)&(n[None,:]<NT)
        a=tl.load(U+up,um,0);b=tl.load(V+vp,vm,0)
        a1=tl.dot(a,b,a1,input_precision=PREC)
        a=tl.load(U2+up,um,0);b=tl.load(V2+vp,vm,0)
        a2=tl.dot(a,b,a2,input_precision=PREC)
    off=((z*G+g)*O+oc[:,None])*NT+n[None,:]
    tl.store(M+off,a1+a2,(oc[:,None]<O)&(n[None,:]<NT))


def _joint8(x,w,ai,aw,bias,d,out,gw,nt,group_batch,sk,ph,pw,precision):
    g,f,c,h,wi=x.shape;_,_,o,p,q=d.shape;total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    for base in range(0,g,group_batch):
        end=min(g,base+group_batch);gb=end-base
        u1=torch.empty((16,gb,o,c),device=x.device,dtype=torch.float32)
        _win_weight_pack[(triton.cdiv(o,16)*triton.cdiv(c,32),gb,16)](w[base:end],u1,gb,c,o,False)
        u2=None
        if aw is not None:
            u2=torch.empty_like(u1)
            _win_weight_pack[(triton.cdiv(o,16)*triton.cdiv(c,32),gb,16)](aw[base:end],u2,gb,c,o,False)
        v=torch.empty((16,gb,c,nt),device=x.device,dtype=torch.float32)
        # gW consumes D before this same allocation is overwritten by transformed X.
        # Each use packs densely from offset zero; max(C,O) is capacity, not stride.
        scratch=torch.empty(16*gb*max(c,o)*nt,device=x.device,dtype=torch.float32)
        m=torch.empty((16,gb,o,nt),device=x.device,dtype=torch.float32)
        acc=torch.empty((gb,sk,16,o,c),device=x.device,dtype=torch.float32);corr=torch.empty_like(acc)
        for start in range(0,total,nt):
            _pack7(ai[base:end],v,start,gb,f,c,h,wi,p,q,ph,pw,nt)
            _pack7(d[base:end],scratch,start,gb,f,o,p,q,p,q,0,0,nt,True)
            _gw7(v,scratch,acc,corr,gb,c,o,nt,sk,start==0,precision)
            if aw is not None:
                _pack7(x[base:end],scratch,start,gb,f,c,h,wi,p,q,ph,pw,nt)
                _packed_dual8[lambda meta:(triton.cdiv(o,meta['BM'])*triton.cdiv(nt,meta['BN']),gb,16)](
                    u1,v,u2,scratch,m,gb,c,o,nt,precision)
            else:_launch_conv7(u1,v,m,gb,c,o,nt,False,precision)
            _win_out[(triton.cdiv(gb*o*nt,128),)](m,bias[base:end] if bias is not None else x,out[base:end],start,gb,f,o,p,q,nt,bias is not None,128)
        _win_gw_out[(triton.cdiv(gb*o*c,64),)](acc,gw[base:end],gb,o,c,sk,64)
        del u1,u2,v,scratch,m,acc,corr


def _v8_winograd_plan(g,f,c,o,h,w,p,q,r,s,sh,sw,ph,pw,dh,dw,dtype,budget,algorithm='auto',split_k=None):
    args=(g,f,c,o,h,w,p,q,r,s,sh,sw,ph,pw,dh,dw,dtype,budget)
    if algorithm=='winograd_v7':return _v7_winograd_plan(*args,'winograd',split_k)
    if algorithm not in ('winograd','winograd_joint','winograd_separate'):
        return _v7_winograd_plan(*args,algorithm,split_k)
    # Reuse validation only. The new execution planner has no fixed group cap.
    _v6_winograd_plan(*args,'winograd',split_k)
    sk=1 if split_k is None else split_k
    budget=min(budget,(2**30-1)*4)
    def choose(total,fixed,per_tile):
        nt=min(512,max(32,512//sk),max(32,triton.next_power_of_2(total)))
        while nt>=32:
            per=64*(fixed+per_tile*nt)
            if per<=budget:
                cap=min(g,budget//per)
                # Reduce unused capacity when fewer groups suffice for the same chunk count.
                gb=triton.cdiv(g,triton.cdiv(g,cap))
                return nt,gb,per*gb
            nt//=2
        return 0,0,0
    total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    nt0,gb0,b0=choose(total,2*c*o,c+o)
    nt1,gb1,b1=choose(f*triton.cdiv(h,2)*triton.cdiv(w,2),c*o,c+o)
    ntw,gbw,bw=choose(total,2*sk*c*o,c+o)
    ntj,gbj,bj=choose(total,(2+2*sk)*c*o,c+o+max(c,o))
    if algorithm=='winograd_separate':ntj=gbj=bj=0
    return dict(version=8,ggO_nt=nt0,gI_nt=nt1,gW_split=sk if ntw else 0,gW_nt=ntw,
                ggO_groups=gb0,gI_groups=gb1,gW_groups=gbw,ggO_pack=bool(nt0),gI_pack=bool(nt1),
                joint_nt=ntj,joint_groups=gbj,scratch_bytes=max(b0,b1,bw,bj),
                schedule='joint_dual' if ntj else 'separate',group_cap='workspace',dual_ggO=bool(ntj))


@triton.jit
def _pack_pair9(X,AI,VX,VI,start,G:tl.constexpr,F:tl.constexpr,C:tl.constexpr,
                H:tl.constexpr,W:tl.constexpr,P:tl.constexpr,Q:tl.constexpr,
                PH:tl.constexpr,PW:tl.constexpr,NT:tl.constexpr):
    # Independent CTAs, one launch. No shared state or cross-group permutation.
    if tl.program_id(2)==0:
        _pack_tiles_all(AI,VI,start,G,F,C,H,W,P,Q,PH,PW,NT,False,128)
    else:
        _pack_tiles_all(X,VX,start,G,F,C,H,W,P,Q,PH,PW,NT,False,128)


@triton.jit
def _weight_pair9(W,AW,U,AU,G:tl.constexpr,C:tl.constexpr,O:tl.constexpr):
    pid=tl.program_id(0);g=tl.program_id(1);plane=tl.program_id(2);z=plane%16
    oc=pid//tl.cdiv(C,32)*16+tl.arange(0,16)
    ci=pid%tl.cdiv(C,32)*32+tl.arange(0,32)
    if plane<16:
        v=_win_weight(W,g,oc[:,None],ci[None,:],z//4,z%4,C,O,False)
        tl.store(U+((z*G+g)*O+oc[:,None])*C+ci[None,:],v,(oc[:,None]<O)&(ci[None,:]<C))
    else:
        v=_win_weight(AW,g,oc[:,None],ci[None,:],z//4,z%4,C,O,False)
        tl.store(AU+((z*G+g)*O+oc[:,None])*C+ci[None,:],v,(oc[:,None]<O)&(ci[None,:]<C))


def _joint9(x,w,ai,aw,bias,d,out,gw,nt,group_batch,sk,ph,pw,precision):
    """Large spatial chunks; each gW partial reduces <=512 tiles by default.

    V(ggI) serves both ggO and gW. Scratch first holds transformed gO in
    [16,G,NT,O], then ggO's GEMM result in [16,G,O,NT]. The two lifetimes do
    not overlap. VX holds transformed input. All buffers die within this call.
    """
    g,f,c,h,wi=x.shape;_,_,o,p,q=d.shape
    total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    for base in range(0,g,group_batch):
        end=min(g,base+group_batch);gb=end-base
        u=torch.empty((16,gb,o,c),device=x.device,dtype=torch.float32)
        au=torch.empty_like(u) if aw is not None else None
        if aw is not None:
            _weight_pair9[(triton.cdiv(o,16)*triton.cdiv(c,32),gb,32)](w[base:end],aw[base:end],u,au,gb,c,o)
        else:_win_weight_pack[(triton.cdiv(o,16)*triton.cdiv(c,32),gb,16)](w[base:end],u,gb,c,o,False)
        v=torch.empty((16,gb,c,nt),device=x.device,dtype=torch.float32)
        vx=torch.empty_like(v) if aw is not None else None
        scratch=torch.empty(16*gb*o*nt,device=x.device,dtype=torch.float32)
        acc=torch.empty((gb,sk,16,o,c),device=x.device,dtype=torch.float32)
        corr=torch.empty_like(acc)
        # Hold group slices once, rather than reconstructing them each tile chunk.
        xx=x[base:end];aa=ai[base:end];dd=d[base:end];yy=out[base:end]
        bb=bias[base:end] if bias is not None else xx
        for start in range(0,total,nt):
            if aw is not None:
                _pack_pair9[(triton.cdiv(c*nt,128),gb,2)](xx,aa,vx,v,start,gb,f,c,h,wi,p,q,ph,pw,nt)
            else:_pack7(aa,v,start,gb,f,c,h,wi,p,q,ph,pw,nt)
            _pack7(dd,scratch,start,gb,f,o,p,q,p,q,0,0,nt,True)
            _gw7(v,scratch,acc,corr,gb,c,o,nt,sk,start==0,precision)
            if aw is not None:
                _packed_dual8[lambda meta:(triton.cdiv(o,meta['BM'])*triton.cdiv(nt,meta['BN']),gb,16)](
                    u,v,au,vx,scratch,gb,c,o,nt,precision)
            else:_launch_conv7(u,v,scratch,gb,c,o,nt,False,precision)
            _win_out[(triton.cdiv(gb*o*nt,128),)](scratch,bb,yy,start,gb,f,o,p,q,nt,bias is not None,128)
        _win_gw_out[(triton.cdiv(gb*o*c,64),)](acc,gw[base:end],gb,o,c,sk,64)
        del u,au,v,vx,scratch,acc,corr


def winograd_plan(g,f,c,o,h,w,p,q,r,s,sh,sw,ph,pw,dh,dw,dtype,budget,algorithm='auto',split_k=None):
    args=(g,f,c,o,h,w,p,q,r,s,sh,sw,ph,pw,dh,dw,dtype,budget)
    if algorithm=='winograd_v8':return _v8_winograd_plan(*args,'winograd',split_k)
    if algorithm!='winograd_large':return _v8_winograd_plan(*args,algorithm,split_k)
    # Validate parameters with the existing path. Explicit opt-in only; no claim
    # that this experimental schedule wins on every supported shape.
    _v6_winograd_plan(*args,'winograd',split_k)
    budget=min(int(budget),(2**30-1)*4)
    total=f*triton.cdiv(p,2)*triton.cdiv(q,2)
    total_i=f*triton.cdiv(h,2)*triton.cdiv(w,2)
    def pick(total,kind):
        target=4096 if kind in ('gI','ggO') else 2048
        nt=min(target,max(32,triton.next_power_of_2(total)))
        while nt>=32:
            # Crucially, increasing split-K does NOT shrink the packed tile chunk.
            # The old planner shrank NT as SK increased, multiplying host loops.
            sk=split_k if split_k is not None else max(1,triton.cdiv(nt,512))
            if kind=='joint':fixed=(2+2*sk)*c*o;per_tile=2*c+o
            elif kind=='gW':fixed=2*sk*c*o;per_tile=c+o
            elif kind=='ggO':fixed=2*c*o;per_tile=c+o
            else:fixed=c*o;per_tile=c+o
            per=64*(fixed+per_tile*nt)
            if per<=budget:
                cap=min(g,budget//per)
                gb=triton.cdiv(g,triton.cdiv(g,cap))
                return nt,gb,per*gb,sk
            nt//=2
        return 0,0,0,0
    ntj,gbj,bj,skj=pick(total,'joint')
    ntw,gbw,bw,skw=pick(total,'gW')
    nt0,gb0,b0,_=pick(total,'ggO')
    nt1,gb1,b1,_=pick(total_i,'gI')
    # Joint and isolated gW must use the same split to keep plan/execution aligned.
    sk=skj if ntj else skw
    if ntw and sk!=skw:
        per=64*(2*sk*c*o+(c+o)*ntw)
        if per>budget:ntw=gbw=bw=0
        else:gbw=min(g,budget//per);bw=gbw*per
    return dict(version=9,ggO_nt=nt0,gI_nt=nt1,gW_split=sk if ntw or ntj else 0,
                gW_nt=ntw,ggO_groups=gb0,gI_groups=gb1,gW_groups=gbw,
                ggO_pack=bool(nt0),gI_pack=bool(nt1),joint_nt=ntj,joint_groups=gbj,
                scratch_bytes=max(b0,b1,bw,bj),schedule='large_joint' if ntj else 'large_separate',
                group_cap='workspace',dual_ggO=bool(ntj),
                joint_tile_chunks=triton.cdiv(total,ntj) if ntj else 0,
                joint_group_chunks=triton.cdiv(g,gbj) if gbj else 0,
                gW_tiles_per_partial=triton.cdiv(ntj or ntw,sk) if sk else 0)
