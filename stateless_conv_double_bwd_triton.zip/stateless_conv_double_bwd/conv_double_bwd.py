"""Stateless group-first convolution double backward; target: NVIDIA sm80+.
No autograd, ATen convolution calls, cached tensors or global scratch buffers.
"""
import torch
import triton
import triton.language as tl

_SHAPE_KEY=['G','F','C','H','W','O','R','S','P','Q','SH','SW','PH','PW','DH','DW','PREC']

def _configs():
    return [triton.Config(dict(BM=m,BN=n,BK=k),num_warps=warps,num_stages=stages)
            for m,n,k,warps,stages in [(16,64,32,4,2),(32,64,32,4,3),
                (32,128,32,4,3),(64,64,32,4,3),(32,64,64,4,3)]]

@triton.autotune(configs=_configs(),key=_SHAPE_KEY+['HI','HW','HB'])
@triton.jit
def _ggo(X,Wt,AI,AW,AB,Y,G:tl.constexpr,F:tl.constexpr,C:tl.constexpr,
         H:tl.constexpr,W:tl.constexpr,O:tl.constexpr,R:tl.constexpr,S:tl.constexpr,
         P:tl.constexpr,Q:tl.constexpr,SH:tl.constexpr,SW:tl.constexpr,
         PH:tl.constexpr,PW:tl.constexpr,DH:tl.constexpr,DW:tl.constexpr,
         PREC:tl.constexpr,HI:tl.constexpr,HW:tl.constexpr,HB:tl.constexpr,
         BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    pid=tl.program_id(0); gf=tl.program_id(1); g=gf//F
    nn=tl.cdiv(P*Q,BN); nm=tl.cdiv(O,BM)
    first=pid//(4*nn)*4; count=tl.minimum(nm-first,4)
    mi=first+(pid%(4*nn))%count; ni=(pid%(4*nn))//count
    oc=mi*BM+tl.arange(0,BM); n=ni*BN+tl.arange(0,BN)
    kk=tl.arange(0,BK)
    acc1=tl.zeros((BM,BN),tl.float32); acc2=tl.zeros((BM,BN),tl.float32)
    if HI or HW:
        for kb in range(tl.cdiv(C*R*S,BK)):
            k=kb*BK+kk
            ih=n[None,:]//Q*SH-PH+(k[:,None]//S%R)*DH
            iw=n[None,:]%Q*SW-PW+(k[:,None]%S)*DW
            xo=gf*C*H*W+(k[:,None]//(R*S))*H*W+ih*W+iw
            wo=g*O*C*R*S+oc[:,None]*C*R*S+k[None,:]
            xm=(k[:,None]<C*R*S)&(n[None,:]<P*Q)&(ih>=0)&(ih<H)&(iw>=0)&(iw<W)
            wm=(oc[:,None]<O)&(k[None,:]<C*R*S)
            if HI:
                a=tl.load(Wt+wo,wm,0); b=tl.load(AI+xo,xm,0)
                acc1=tl.dot(a,b,acc1,input_precision=PREC)
            if HW:
                a=tl.load(AW+wo,wm,0); b=tl.load(X+xo,xm,0)
                acc2=tl.dot(a,b,acc2,input_precision=PREC)
    # Match the intermediate dtype rounding of the two ATen conv outputs.
    if HI and HW:
        val=(acc1.to(Y.dtype.element_ty).to(tl.float32)+acc2.to(Y.dtype.element_ty).to(tl.float32)).to(Y.dtype.element_ty).to(tl.float32)
    elif HI:
        val=acc1.to(Y.dtype.element_ty).to(tl.float32)
    else:
        val=acc2.to(Y.dtype.element_ty).to(tl.float32)
    if HB:
        val+=tl.load(AB+g*O+oc,oc<O,0)[:,None]
    tl.store(Y+(gf*O+oc[:,None])*P*Q+n[None,:],val,(oc[:,None]<O)&(n[None,:]<P*Q))

@triton.autotune(configs=_configs(),key=_SHAPE_KEY)
@triton.jit
def _gi(D,AW,Y,G:tl.constexpr,F:tl.constexpr,C:tl.constexpr,
        H:tl.constexpr,W:tl.constexpr,O:tl.constexpr,R:tl.constexpr,S:tl.constexpr,
        P:tl.constexpr,Q:tl.constexpr,SH:tl.constexpr,SW:tl.constexpr,
        PH:tl.constexpr,PW:tl.constexpr,DH:tl.constexpr,DW:tl.constexpr,
        PREC:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    pid=tl.program_id(0); gf=tl.program_id(1); g=gf//F
    nn=tl.cdiv(H*W,BN)
    ci=pid//nn*BM+tl.arange(0,BM); n=pid%nn*BN+tl.arange(0,BN)
    kk=tl.arange(0,BK); acc=tl.zeros((BM,BN),tl.float32)
    # Gather dgrad: no expanded dY and no col2im/atomic scatter.
    for kb in range(tl.cdiv(O*R*S,BK)):
        k=kb*BK+kk; oc=k//(R*S); r=k//S%R; s=k%S
        hp=n[None,:]//W+PH-r[:,None]*DH
        wp=n[None,:]%W+PW-s[:,None]*DW
        py=hp//SH; qx=wp//SW
        a=tl.load(AW+g*O*C*R*S+oc[None,:]*C*R*S+ci[:,None]*R*S+r[None,:]*S+s[None,:],
                  (ci[:,None]<C)&(oc[None,:]<O),0)
        b=tl.load(D+gf*O*P*Q+oc[:,None]*P*Q+py*Q+qx,
                  (oc[:,None]<O)&(n[None,:]<H*W)&(hp%SH==0)&(wp%SW==0)&
                  (py>=0)&(py<P)&(qx>=0)&(qx<Q),0)
        acc=tl.dot(a,b,acc,input_precision=PREC)
    tl.store(Y+(gf*C+ci[:,None])*H*W+n[None,:],acc,(ci[:,None]<C)&(n[None,:]<H*W))

@triton.autotune(configs=_configs(),key=_SHAPE_KEY+['SPLIT'])
@triton.jit
def _gw(AI,D,Y,G:tl.constexpr,F:tl.constexpr,C:tl.constexpr,
        H:tl.constexpr,W:tl.constexpr,O:tl.constexpr,R:tl.constexpr,S:tl.constexpr,
        P:tl.constexpr,Q:tl.constexpr,SH:tl.constexpr,SW:tl.constexpr,
        PH:tl.constexpr,PW:tl.constexpr,DH:tl.constexpr,DW:tl.constexpr,
        PREC:tl.constexpr,SPLIT:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    pid=tl.program_id(0); gs=tl.program_id(1); g=gs//SPLIT; part=gs%SPLIT
    nn=tl.cdiv(C*R*S,BN)
    oc=pid//nn*BM+tl.arange(0,BM); crs=pid%nn*BN+tl.arange(0,BN)
    ci=crs//(R*S); r=crs//S%R; s=crs%S
    kk=tl.arange(0,BK); acc=tl.zeros((BM,BN),tl.float32)
    # Contract F*P*Q directly; split only when the output grid is too small.
    for block in range(tl.cdiv(F*P*Q,SPLIT*BK)):
        k=(block*SPLIT+part)*BK+kk
        f=k//(P*Q); py=k//Q%P; qx=k%Q
        ih=py[:,None]*SH-PH+r[None,:]*DH
        iw=qx[:,None]*SW-PW+s[None,:]*DW
        a=tl.load(D+g*F*O*P*Q+f[None,:]*O*P*Q+oc[:,None]*P*Q+py[None,:]*Q+qx[None,:],
                  (oc[:,None]<O)&(k[None,:]<F*P*Q),0)
        b=tl.load(AI+g*F*C*H*W+f[:,None]*C*H*W+ci[None,:]*H*W+ih*W+iw,
                  (k[:,None]<F*P*Q)&(crs[None,:]<C*R*S)&(ih>=0)&(ih<H)&(iw>=0)&(iw<W),0)
        acc=tl.dot(a,b,acc,input_precision=PREC)
    tl.store(Y+gs*O*C*R*S+oc[:,None]*C*R*S+crs[None,:],acc,
             (oc[:,None]<O)&(crs[None,:]<C*R*S))

@triton.jit
def _reduce(T,Y,N:tl.constexpr,PER:tl.constexpr,SPLIT:tl.constexpr,BLOCK:tl.constexpr):
    i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK)
    g=i//PER; j=i%PER
    acc=tl.full((BLOCK,),0,tl.float32)
    for s in tl.static_range(SPLIT):
        acc+=tl.load(T+(g*SPLIT+s)*PER+j,i<N,0)
    tl.store(Y+i,acc,i<N)


def _pair(x):
    if isinstance(x,int): return (x,x)
    x=tuple(x)
    if len(x)==1: x=x*2
    if len(x)!=2 or any(not isinstance(v,int) for v in x): raise ValueError('Expected int or 1/2 integer sequence')
    return x


def workspace_split(g,f,c,o,r,s,p,q,num_sms,budget_bytes):
    """Bounded heuristic, not a measured optimum. No workspace for split=1."""
    tiles=g*triton.cdiv(o,32)*triton.cdiv(c*r*s,64)
    want=min(16,max(1,triton.cdiv(2*num_sms,tiles)),max(1,(f*p*q)//256))
    split=1
    while split*2<=want: split*=2
    per=g*o*c*r*s*4
    while split>1 and per*split>budget_bytes: split//=2
    return split


def convolution_double_backward(ggI_opt,ggW_r_opt,ggb_opt,gO_r,weight_r,input,
        stride_,padding_,dilation_,transposed_,output_padding_,groups_,output_mask,
        *,precision='ieee',workspace_limit_mb=32,split_k=None):
    """ATen argument order; tensors have explicit leading independent group G.

    input/ggI [G,F,C,H,W]; weight/ggW [G,O,C,R,S]; gO [G,F,O,P,Q]; ggb [G,O].
    groups_=1 means dense convolution INSIDE each independent outer group.
    Returns (ggO,gI,gW), missing terms are None. Matches PyTorch 2.5.1's
    ignored output_mask; use optional ggI/ggW/ggb=None to omit terms.
    Non-transposed 2D only. No autograd graph; no retained tensor state.
    """
    if transposed_ or groups_!=1 or _pair(output_padding_)!=(0,0):
        raise NotImplementedError('Only transposed=False, output_padding=0, inner groups=1; outer G inferred from input')
    if len(output_mask)!=3: raise ValueError('output_mask must have 3 entries')
    if input.ndim!=5 or weight_r.ndim!=5: raise ValueError('Expected 5D group-first input/weight')
    g,f,c,h,w=input.shape; gw,o,cw,r,s=weight_r.shape
    sh,sw=_pair(stride_); ph,pw=_pair(padding_); dh,dw=_pair(dilation_)
    if min(*input.shape,*weight_r.shape,sh,sw,dh,dw)<=0 or min(ph,pw)<0 or (g,c)!=(gw,cw):
        raise ValueError('Invalid dimensions or convolution parameters')
    p=(h+2*ph-dh*(r-1)-1)//sh+1; q=(w+2*pw-dw*(s-1)-1)//sw+1
    if min(p,q)<=0 or tuple(gO_r.shape)!=(g,f,o,p,q): raise ValueError('Invalid gO shape')
    for t,shape in [(ggI_opt,input.shape),(ggW_r_opt,weight_r.shape),(ggb_opt,(g,o))]:
        if t is not None and tuple(t.shape)!=tuple(shape): raise ValueError('Optional tensor shape mismatch')
    ts=[input,weight_r,gO_r]+[t for t in (ggI_opt,ggW_r_opt,ggb_opt) if t is not None]
    if input.dtype not in (torch.float32,torch.float16,torch.bfloat16): raise TypeError('FP32/FP16/BF16 required')
    for t in ts:
        if not t.is_cuda or t.device!=input.device or t.dtype!=input.dtype or not t.is_contiguous():
            raise ValueError('All inputs must be contiguous, same CUDA device/dtype')
        if torch.is_grad_enabled() and t.requires_grad: raise RuntimeError('Stateless manual derivative: call under torch.no_grad()')
    if max(t.numel() for t in ts)>=2**30 or g*f>65535: raise ValueError('Shape exceeds conservative indexing/grid limits')
    if precision not in ('ieee','tf32','tf32x3'): raise ValueError('Unsupported precision')
    if workspace_limit_mb<0: raise ValueError('Negative workspace budget')
    ggO=gI=gW=None
    with torch.cuda.device(input.device):
        dims=(g,f,c,h,w,o,r,s,p,q,sh,sw,ph,pw,dh,dw,precision)
        hi=ggI_opt is not None; hw=ggW_r_opt is not None; hb=ggb_opt is not None
        if hi or hw or hb:
            ggO=torch.empty_like(gO_r)
            _ggo[lambda m:(triton.cdiv(o,m['BM'])*triton.cdiv(p*q,m['BN']),g*f)](
                input,weight_r,ggI_opt if hi else input,ggW_r_opt if hw else weight_r,
                ggb_opt if hb else input,ggO,*dims,hi,hw,hb)
        if hw:
            gI=torch.empty_like(input)
            _gi[lambda m:(triton.cdiv(c,m['BM'])*triton.cdiv(h*w,m['BN']),g*f)](gO_r,ggW_r_opt,gI,*dims)
        if hi:
            budget=int(workspace_limit_mb*1024**2)
            sk=workspace_split(g,f,c,o,r,s,p,q,torch.cuda.get_device_properties(input.device).multi_processor_count,budget) if split_k is None else split_k
            if sk not in (1,2,4,8,16) or g*sk>65535: raise ValueError('Invalid split_k')
            ne=g*o*c*r*s
            if sk>1 and (ne*sk*4>budget or ne*sk>=2**30): raise ValueError('Split-K exceeds workspace/indexing budget')
            gW=torch.empty_like(weight_r)
            tmp=torch.empty((g,sk,o,c,r,s),device=input.device,dtype=torch.float32) if sk>1 else gW
            _gw[lambda m:(triton.cdiv(o,m['BM'])*triton.cdiv(c*r*s,m['BN']),g*sk)](ggI_opt,gO_r,tmp,*dims,sk)
            if sk>1: _reduce[(triton.cdiv(ne,256),)](tmp,gW,ne,o*c*r*s,sk,256)
    return ggO,gI,gW

_convolution_double_backward=convolution_double_backward
